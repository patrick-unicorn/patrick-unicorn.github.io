﻿using Monstar.U3D.Utility;
using Monstar.Unity.Network.Tcp.IOEventHanders;
using Monstar.Unity.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp.Demo {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-11-23
    //
    //======================================================================

    public class DemoSerializationFactory : ISerializationFactory {

        public static readonly AttributeKey K_ENCODING = new AttributeKey(typeof(DemoSerializationFactory), "encoding");

        private DemoSerialzer serializer;

        private DemoDeserializer deserializer;

        public DemoSerializationFactory() {
            this.serializer = new DemoSerialzer();
            this.deserializer = new DemoDeserializer();
        }

        public ISerialize Serializer {
            get { return serializer; }
        }

        public IDeserialize Deserializer {
            get { return deserializer; }
        }

    }

    class DemoSerialzer : ISerialize {

        static readonly AttributeKey K_ENCODING = DemoSerializationFactory.K_ENCODING;

        public object Serialize(IRemoter remoter, object data) {
            IRequestWrapper request = data as IRequestWrapper;
            if (request == null || request.Data == null) {
                throw new ArgumentNullException("data");
            }
            Encoding encoding = (Encoding) remoter.GetAttribute(K_ENCODING);
            if (encoding == null) {
                encoding = Encoding.GetEncoding(remoter.Configure.CharEncode);
                remoter.AddAttribute(K_ENCODING, encoding);
            }
            return encoding.GetBytes(DoSerialize((DemoRequest) request.Data));
        }

        private string DoSerialize(DemoRequest request) {
            Dictionary<string, object> map = new Dictionary<string, object>();
            map.Add("id", request.ID);
            map.Add("enableKeepAlive", request.EnableKeepAlive);
            map.Add("dataType", request.DataType);
            map.Add("version", request.Version);
            map.Add("mode", request.Mode);
            map.Add("client", request.Client);
            map.Add("expire", request.Expire);
            map.Add("path", request.Path);
            map.Add("reqFormat", request.ReqFormat);
            map.Add("resFormat", request.ResFormat);
            map.Add("reqEcr", request.ReqEcr);
            map.Add("resEcr", request.ResEcr);
            map.Add("parameters", request.Parameters);

            return Json.Serialize(map);
        }
    }

    class DemoDeserializer : IDeserialize {

        static readonly AttributeKey K_ENCODING = DemoSerializationFactory.K_ENCODING;

        public object DeSerialize(IRemoter remoter, object data) {
            IResponseWrapper response = data as IResponseWrapper;
            if (response == null || response.Data == null) {
                throw new ArgumentNullException("data");
            }
            byte[] inbytes = response.Data as byte[];
            if (inbytes == null || inbytes.Length <= 0) {
                throw new ArgumentNullException("response.data");
            }

            Encoding encoding = (Encoding) remoter.GetAttribute(K_ENCODING);
            if (encoding == null) {
                encoding = Encoding.GetEncoding(remoter.Configure.CharEncode);
                remoter.AddAttribute(K_ENCODING, encoding);
            }

            return new DefaultResponse(
                DoDeserialize(encoding.GetString(inbytes)), response.IsMessage);
        }

        private DemoResponse DoDeserialize(string json) {
            IDictionary<string, object> dic = Json.Deserialize(json) as IDictionary<string, object>;
            DemoResponse response = new DemoResponse();

            if (dic.ContainsKey("code")) {
                response.Code = dic["code"].ToString();
            }

            if (dic.ContainsKey("serverTime")) {
                response.ServerTime = long.Parse(dic["serverTime"].ToString());
            }

            if (dic.ContainsKey("dataType")) {
                response.DataType = (DataType) Enum.Parse(typeof(DataType), dic["dataType"].ToString());
            }

            if (dic.ContainsKey("model")) {
                response.Model = dic["model"];
            }

            if (dic.ContainsKey("exp") && dic["exp"] != null) {
                response.Exp = dic["exp"].ToString();
            }

            response.Source = json;
            return response;
        }
    }

}
