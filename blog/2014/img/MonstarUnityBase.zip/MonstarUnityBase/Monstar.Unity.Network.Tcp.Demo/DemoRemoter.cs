﻿using Monstar.U3D.Utility.Log;
using Monstar.Unity.Network.Tcp.IOEventHanders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp.Demo {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-11-23
    //
    //======================================================================

    class DemoRemoter : AbstractRemoter {

        public DemoRemoter() : base(new TcpConnector(), new TcpIoProcessor()) 
        {
            this.Configure = new RemoterConfig();
            this.Configure.Host = "192.168.10.176";
            this.Configure.Port = 8078;
            this.Configure.CharEncode = "utf-8";

            /* 此处为方便测试，缓冲区各项值均设置较小，实际应用可采用默认值 */
            this.Configure.RecieveBufferSize = 1024;
            this.Configure.SendBufferSize = 1024;

            this.Configure.KeepAliveInterval = 10;
            this.Configure.KeepAliveTimeout = 5;
            this.Configure.IsKeepAlive = true;
            this.Configure.ConnectTimeout = 3 * 1000;
            this.Configure.RecieveTimeout = 3 * 1000;
            this.Configure.SendTimeout = 3 * 1000;
            this.Configure.CompressionLevel = 9;
            this.Configure.EncryptIVParamter = "jBx,#m68{pnYE@q%";
            this.Configure.EncryptPrivateKey = "";
            this.Configure.EncryptPublicKey = "mt*_2x@6(&08F,%z";
            this.Configure.ReqHeartBeat = "@QT$";
            this.Configure.ResHeartBeat = "$SS@";
            this.Configure.TurnOnPing = true;

            this.DataHandler = new DemoDataHandler();
            // 构造IO执行链
            this.IOEventHandlerChainBuilder
                .Append(new KeepAliveHandler(Configure.KeepAliveInterval,
                                             Configure.KeepAliveTimeout,
                                             new DemoKeepAliveMessageFactory(Configure),
                                             this.HandleKeepAliveTimeout))
                .Append(new PackageHandler(new DemoPackageFactory()))
                .Append(new EncryptionHandler(new AESFactory(Configure.EncryptPublicKey, 
                                                             Configure.EncryptIVParamter)))
                .Append(new CompressionHandler(new ZIPFactory()))
                .Append(new SerializationHandler(new DemoSerializationFactory()));
        }

        private void HandleKeepAliveTimeout(IRemoter remoter) {
            remoter.Stop(null);
            remoter.HandleException(new TimeoutException("Hearbeat timeout"), remoter);
        }

        public static void PrintExHandler(Exception cause, object state) {
            Log4netWrapper.D.Error(cause);
        }

        public object Send(object request) {
            return Request(request,
                delegate(object result, object state) {
                    IResponseWrapper responseWrapper = (IResponseWrapper) result;
                    DemoResponse response = (DemoResponse) responseWrapper.Data;
                    Log4netWrapper.D.Debug(response.Source);
                }, -1);
        }

    }

    public class TestCase {

        /// <summary>
        /// 回音测试(短连接阻塞)
        /// </summary>
        public void Echo_0(string message) {
            DemoRequest request = new DemoRequest();
            request.DataType = DataType.TEXT;
            request.Version = "1.0";
            request.EnableKeepAlive = true;
            request.Mode = ReqModeType.RELEASE;
            request.Client = "Iphone";
            request.Expire = 0;
            request.Path = "/echo/echo";
            request.Parameters.Add("playerId", "13");

            // 由于IRemoter对象创建成本较高，因此，在实际场景中，建议可对DemoRemoter做对象池或单例 。
            DemoRemoter r = new DemoRemoter();
            r.Start(null);
            r.Send(request);
            r.Stop(null);
        }

        /// <summary>
        /// 回音测试(长连接阻塞)
        /// </summary>
        public void Echo_1(string message) {
            DemoRequest request = new DemoRequest();
            request.DataType = DataType.TEXT;
            request.Version = "1.0";
            request.EnableKeepAlive = true;
            request.Mode = ReqModeType.RELEASE;
            request.Client = "Iphone";
            request.Expire = 0;
            request.Path = "/echo/echo";
            request.Parameters.Add("playerId", "13");

            // 由于IRemoter对象创建成本较高，因此，在实际场景中，建议可对DemoRemoter做对象池或单例 。
            DemoRemoter r = new DemoRemoter();
            r.Start(null);
            for (int i=0; i < 10; i++) {
                r.Send(request);
            }
        }
    }
}
