﻿using Monstar.U3D.Utility.Log;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp.Demo {

    class Client {
        static void Main(string[] args) {
            Log4netWrapper.Configure();

            try {
                Demo_0 d_0 = new Demo_0();
                Demo_1 d_1 = new Demo_1();

                //d_0.Run();
                d_1.Run();
            } catch (Exception e) {
                Log4netWrapper.D.Debug(e);
            }
            Console.ReadLine();
        }
    }

    /// <summary>
    /// 场景：
    ///     使用短连接，阻塞访问
    /// </summary>
    class Demo_0 {

        private TestCase tc = new TestCase();

        public void Run() {
            tc.Echo_0("The is an echo message.");
        }
    }

    /// <summary>
    /// 场景：
    ///     使用长连接，阻塞访问
    /// </summary>
    class Demo_1 {

        private TestCase tc = new TestCase();

        public void Run() {
            tc.Echo_1("The is an echo message.");
        }
    }

    /// <summary>
    /// 场景：
    ///     使用短连接，异步访问
    /// </summary>
    class Demo_2 {

        private TestCase tc = new TestCase();

        public void Run() {
            throw new NotImplementedException();
        }
    }

    /// <summary>
    /// 场景：
    ///     使用长连接，异步访问
    /// </summary>
    class Demo_3 {

        private TestCase tc = new TestCase();

        public void Run() {
            throw new NotImplementedException();
        }
    }
}
