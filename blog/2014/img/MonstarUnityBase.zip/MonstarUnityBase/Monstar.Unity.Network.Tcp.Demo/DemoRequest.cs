﻿using Monstar.Unity.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp.Demo {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-11-23
    //
    //======================================================================

    public enum DataType {
        TEXT = 1,
        IMAGE,
        FILE,
        MESSAGE
    }

    class DemoRequest {

        public string ID { get; set; }

        public bool EnableKeepAlive { get; set; }

        public DataType DataType { get; set; }

        public String Version { get; set; }

        public ReqModeType Mode { get; set; }

        public String Client { get; set; }

        public int Expire { get; set; }

        public String Path { get; set; }

        /**
         * The input data from client, it's similar to
         * the HTTP get parameters. And this object is readonly, 
         * it will be initialize by {@link #setOriginParameters}
         */
        public IDictionary<String, object> Parameters { get; set; }

        public TextFormat ReqFormat {
            get {
                return TextFormat.JSON;
            }
        }

        public TextFormat ResFormat {
            get {
                return TextFormat.JSON;
            }
        }

        public Encryption ReqEcr { get; set; }

        public Encryption ResEcr { get; set; }

        public DemoRequest() {
            ID = IdGenerator.Generate();
            Parameters = new Dictionary<string, object>();
        }

    }

    public class Encryption {

        public bool yes;

        public EncryptionType scheme;

        public IDictionary<String, String> attrs;
    }

    public enum EncryptionType {
        DES = 1,
        AES,
        NOP
    }

    public enum TextFormat {

        PLAINTEXT = 1,
        JSON,
        XML,
        JSONP,
        PROTOCOL,
        THRIFT
    }

    public enum ReqModeType {
        DEBUG = 1,
        RELEASE
    }

}
