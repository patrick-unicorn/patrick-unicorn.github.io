﻿using Monstar.U3D.Utility;
using Monstar.Unity.Network.Tcp.IOEventHanders;
using Monstar.Unity.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp.Demo {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-11-23
    //
    //======================================================================


    /***********************************************************************
     * 
     * 本Demo中定义的二进制协议如下：
      -------------------------------------------------------
      | DataType | Content-Length |          Content        |        
      -------------------------------------------------------
      | 1 byte   |    2 bytes     |          n bytes        |       
      -------------------------------------------------------
     * 
     * 其中DataTyp(0 - 表示响应   1 - 表示单向消息)用于表示消息响应类型，在实际
     * 的应用中，也可以将该字节去除，转而在Content中以对象化形式表述消息响应类型。
     * 
     * *********************************************************************/

    class DemoPackageFactory : IPackageFactory  {

        private DemoPacker packer;

        private DemoUnPacker unpacker;

        public DemoPackageFactory() {
            this.packer = new DemoPacker();
            this.unpacker = new DemoUnPacker();
        }

        public IPacker Packer {
            get { return packer; }
        }

        public IUnPacker UnPacker {
            get { return unpacker; }
        }

    }

    class DemoPacker : IPacker {

        public IoBuffer Pack(IRemoter remoter, object data) {
            byte[] bytes = data as byte[];
            if (data == null || bytes.Length <= 0) {
                throw new ArgumentException("Data must be non-empty byte array");
            }
            
            // 此处不对发送消息的类型做区分，实际应用取决于服务端要求
            byte headByte = (byte) 1;
            byte[] lengthBytes = BitConverter.GetBytes(bytes.Length);
            // 转换为大端(网络)字节序
            if (BitConverter.IsLittleEndian) {
                Array.Reverse(lengthBytes);
            }

            IoBuffer buffer = IoBuffer.Allocate()
                                      .Put(headByte)
                                      .Put(lengthBytes, 2, 2)
                                      .Put(bytes)
                                      .Flip();
            return buffer;
        }

    }

    class DemoUnPacker : CumulatedUnPacker {

        static readonly int DATA_TYPE_BLEN = 1;

        static readonly int DATA_LEN_BLEN = 2;

        protected override bool DoUnPack(IRemoter remoter, IoBuffer buffer) {
            if (buffer.Remaining < DATA_TYPE_BLEN) {
                return false;
            }
            byte headByte = buffer.Get();

            if (buffer.Remaining < DATA_LEN_BLEN) {
                buffer.Rewind();
                return false;
            }
            byte[] lengthBytes = new byte[DATA_LEN_BLEN];
            buffer.Get(lengthBytes, 0, DATA_LEN_BLEN);
            Array.Reverse(lengthBytes);
            ushort bodyLen = BitConverter.ToUInt16(lengthBytes, 0);

            if (buffer.Remaining < bodyLen) {
                buffer.Rewind();
                return false;
            }
            byte[] inBytes = new byte[bodyLen];
            buffer.Get(inBytes);

            StorePacket(remoter, new DefaultResponse(inBytes, headByte == 1 ? false : true));
            return true;
        }
    }
    
}
