﻿using Monstar.Unity.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp.Demo {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-11-23
    //
    //======================================================================

    class DemoResponse {

        public const string SUCC_CODE = "000";

        private DataType dataType;

        private string code;

        private long serverTime;

        private object model;

        private string exp;

        private string source;

        public bool Success {
            get {
                return code == SUCC_CODE;
            }
        }
		
		public Dictionary<string, object> Attrs { 
            get;
            set;
        }
		
		/// <summary>
        /// the message type
        /// </summary>
        public DataType DataType {
            get;
            set;
        }

        public long ServerTime {
            get;
            set;
        }
		
		/// <summary>
        /// Represent the response status code, eg. 000 - success
        /// </summary>
        public string Code {
            get;
            set;
        }
		
		/// <summary>
        /// Domain model's JSON string
        /// </summary>
        public object Model {
            get;
            set;
        }
		
		/// <summary>
        /// Server exception information during process the request
		/// </summary>
		public string Exp{ 
            get; 
            set; 
        }

        /// <summary>
        /// The original string source.
        /// </summary>
        public string Source {
            get;
            set;
        }
		
		public DemoResponse() {
		}

        public override string ToString() {
            return Source;
        }

    }
}
