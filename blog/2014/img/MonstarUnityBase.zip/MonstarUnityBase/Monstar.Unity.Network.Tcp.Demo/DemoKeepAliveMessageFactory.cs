﻿using Monstar.Unity.Network.Tcp.IOEventHanders;
using Monstar.Unity.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp.Demo {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-11-23
    //
    //======================================================================

    class DemoKeepAliveMessageFactory : KeepAlivePacketFactory {

        /// <summary>
        /// 心跳请求包字符串
        /// </summary>
        private readonly String HB_REQ;

        /// <summary>
        /// 心跳响应包字符串
        /// </summary>
        private readonly String HB_RES;

        /// <summary>
        /// 心跳请求包二进制串
        /// </summary>
        private readonly byte[] B_HB_REQ;

        /// <summary>
        /// 心跳响应包二进制串
        /// </summary>
        private readonly byte[] B_HB_RES;

        /// <summary>
        /// 心跳请求包二进制串长度
        /// </summary>
        private readonly int B_HB_REQ_LEN;

        /// <summary>
        /// 心跳响应包二进制串长度
        /// </summary>
        private readonly int B_HB_RES_LEN;

        private Encoding encoding;

        public DemoKeepAliveMessageFactory(RemoterConfig config) {
            encoding = Encoding.GetEncoding(config.CharEncode);

            HB_REQ = config.ReqHeartBeat;
            HB_RES = config.ResHeartBeat;

            B_HB_REQ = encoding.GetBytes(HB_REQ);
            B_HB_RES = encoding.GetBytes(HB_RES);
            B_HB_REQ_LEN = B_HB_REQ.Length;
            B_HB_RES_LEN = B_HB_RES.Length;
        }

        public bool IsRequest(IRemoter remoter, object packet) {
            IoBuffer buffer = packet as IoBuffer;
            if (buffer == null || buffer.Remaining < B_HB_REQ_LEN) {
                return false;
            }

            byte[] bytes = new byte[B_HB_REQ_LEN];
            buffer.Get(bytes);
            bool isREQ = encoding.GetString(bytes).Equals(HB_REQ);

            if (isREQ) {
                buffer.Compact();
                buffer.Flip();
            } else {
                buffer.Rewind();
            }

            return isREQ;
        }

        public bool IsResponse(IRemoter remoter, object packet) {
            IoBuffer buffer = packet as IoBuffer;
            if (buffer == null || buffer.Remaining < B_HB_RES_LEN) {
                return false;
            }

            byte[] bytes = new byte[B_HB_RES_LEN];
            buffer.Get(bytes);
            bool isRES = encoding.GetString(bytes).Equals(HB_RES);

            if (isRES) {
                buffer.Compact();
                buffer.Flip();
            } else {
                buffer.Rewind();
            }

            return isRES;
        }

        public object GetRequest(IRemoter remoter) {
            return IoBuffer.Wrap(B_HB_REQ);
        }

        public object GetResponse(IRemoter remoter, object request) {
            return IoBuffer.Wrap(B_HB_RES);
        }
    }
}
