﻿using System;
using System.Collections.Generic;

using System.Text;

namespace Monstar.Unity.Utility {
    public static class DateTimeExtension {

        public static readonly DateTime STD_TIME = new DateTime(1970, 1, 1, 8, 0, 0, DateTimeKind.Utc);

        /// <summary>
        /// Calculate the milliseconds between the given UTC time 
        /// and <code>STD_TIME</code>
        /// </summary>
        /// <param name="dt">An UTC time</param>
        /// <returns></returns>
        public static long TotalMillis(DateTime dt) {
            return (long) dt.Subtract(STD_TIME).TotalMilliseconds;
        }

        /// <summary>
        /// Calculate the milliseconds between the <code>DateTime.Now</code>
        /// and <code>STD_TIME</code>
        /// </summary>
        public static long CurrentTimeMillis {
            get {
                return TotalMillis(DateTime.Now);
            }
        }
    }
}
