﻿using ComponentAce.Compression.Libs.zlib;
using System;
using System.Collections.Generic;
using System.Text;

/* ======================================================================
//
//        Copyright(c)  http://www.monstar-lab.com/
//        All rights reserved

//        CLR:               .NET Framework 2.0           
//        description :          

//        created by unicorn(haiyin-ma) at  2013-7-13
//
//====================================================================== */
namespace Monstar.Unity.Utility {

    /// <summary>
    /// 
    /// </summary>
    public enum ECompressionLevel {
        /// <summary>
        /// 
        /// </summary>
        DEFAULT = zlibConst.Z_DEFAULT_COMPRESSION,
        /// <summary>
        /// 
        /// </summary>
        MIN = zlibConst.Z_BEST_SPEED,
        /// <summary>
        /// 
        /// </summary>
        MAX = zlibConst.Z_BEST_COMPRESSION,
        /// <summary>
        /// 
        /// </summary>
        NONE = zlibConst.Z_NO_COMPRESSION,
    }

    /// <summary>
    /// 
    /// </summary>
    public enum EZipMode {
        /// <summary>
        /// 
        /// </summary>
        COMPRESS = 1,
        /// <summary>
        /// 
        /// </summary>
        DECOMPRESS
    }

    /// <summary>
    /// A helper class for interfacing with the zlib.net library. This class acts 
    /// both as a compressor and decompressor, but only as one at a time. 
    /// The only flush method supported is Z_SYNC_FLUSH also known as Z_PARTIAL_FLUSH.
    /// 
    /// This class is similar to the MINA CompressionFilter.
    /// </summary>
    public class Zlib {

        const string ERROR = "Error code : ";

        private ZStream zStream;

        private EZipMode mode;

        private ECompressionLevel compressionLevel;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="mode"></param>
        public Zlib(EZipMode mode) 
            : this(mode, ECompressionLevel.DEFAULT) {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="mode"></param>
        /// <param name="compressionLevel"></param>
        public Zlib(EZipMode mode, ECompressionLevel compressionLevel) {
            zStream = new ZStream();

            this.compressionLevel = compressionLevel;

            switch (mode) {
                case EZipMode.COMPRESS:
                    zStream.deflateInit((int) compressionLevel);
                    break;
                case EZipMode.DECOMPRESS:
                    zStream.inflateInit();
                    break;
                default:
                    throw new ArgumentOutOfRangeException("mode");
            }
        }

        /// <summary>
        /// Compress the input. The result will be put in a new buffer.
        /// </summary>
        /// <param name="buffer"></param>
        /// <returns></returns>
        public IoBuffer Compress(IoBuffer inBuffer) {
            byte[] inBytes = new byte[inBuffer.Remaining];
            inBuffer.Get(inBytes).Flip();

            // according to spec, destination buffer should be 0.1% larger
            // than source length plus 12 bytes. We add a single byte to safeguard
            // against rounds that round down to the smaller value
            int outLen = (int) Math.Round(inBytes.Length * 1.001) + 1 + 12;
            byte[] outBytes = new byte[outLen];

            lock (zStream) {
                zStream.next_in = inBytes;
                zStream.next_in_index = 0;
                zStream.avail_in = inBytes.Length;
                zStream.next_out = outBytes;
                zStream.next_out_index = 0;
                zStream.avail_out = outBytes.Length;

                int retval = zStream.deflate(zlibConst.Z_SYNC_FLUSH);
                if (retval != zlibConst.Z_OK) {
                    outBytes = null;
                    inBytes = null;
                    throw new CompressionException(ERROR + retval);
                }

                IoBuffer outBuf = IoBuffer.Wrap(outBytes, 0, zStream.next_out_index);

                return outBuf;
            }
        }

        /// <summary>
        /// DeCompress the input. The result will be put in a new buffer.
        /// </summary>
        /// <param name="inBuffer"></param>
        /// <returns></returns>
        public IoBuffer Decompress(IoBuffer inBuffer) {
            byte[] inbytes = new byte[inBuffer.Remaining];
            inBuffer.Get(inbytes).Flip();

            byte[] outBytes = new byte[inbytes.Length * 2];
            IoBuffer outBuffer = IoBuffer.Allocate(outBytes.Length);

            lock (zStream) {
                zStream.next_in = inbytes;
                zStream.next_in_index = 0;
                zStream.avail_in = inbytes.Length;
                zStream.next_out = outBytes;
                zStream.next_out_index = 0;
                zStream.avail_out = outBytes.Length;

                int retval = 0;

                do {
                    retval = zStream.inflate(zlibConst.Z_SYNC_FLUSH);

                    switch (retval) {
                        case zlibConst.Z_OK:
                            // completed decompression, lets copy data and get out
                        case zlibConst.Z_BUF_ERROR:
                            // need more space for output. store current output and get more
                            outBuffer.Put(outBytes, 0, zStream.next_out_index);
                            zStream.next_out_index = 0;
                            zStream.avail_out = outBytes.Length;
                            break;
                        default:
                            // unknown error
                            outBuffer = null;
                            if (zStream.msg == null) {
                                throw new DecompressionException(ERROR + retval);
                            } else {
                                throw new DecompressionException(ERROR + retval 
                                    + " and message : " + zStream.msg);
                            }
                    }
                } while (zStream.avail_in > 0);

                return outBuffer.Flip();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public void Dipose() {
            if (zStream != null) {
                zStream.free();
            }
        }
    }

    class CompressionException : Exception {
        public CompressionException() {

        }

        public CompressionException(string message)
            : base(message) {

        }

        public CompressionException(Exception cause)
            : base("", cause) {

        }

        public CompressionException(string message, Exception cause)
            : base(message, cause) {

        }
    }

    class DecompressionException : Exception {
        public DecompressionException() {

        }

        public DecompressionException(string message)
            : base(message) {

        }

        public DecompressionException(Exception cause)
            : base("", cause) {

        }

        public DecompressionException(string message, Exception cause)
            : base(message, cause) {

        }
    }
}
