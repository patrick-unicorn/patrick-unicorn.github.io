﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.U3D.Utility {
    public class ConcurrencyQueue<T> : IEnumerable<T>, ICollection, IEnumerable {

        private object syncRoot = new object();

        private Queue<T> queue;

        public ConcurrencyQueue() {
            queue = new Queue<T>();
        }

        public ConcurrencyQueue(int capacity) {
            queue = new Queue<T>(capacity);
        }

        public int Count {
            get {
                lock (syncRoot) {
                    return queue.Count;
                }
            }
        }

        public bool IsSynchronized {
            get { return true; }
        }

        public T Dequeue() {
            lock (syncRoot) {
                if (queue.Count <= 0) {
                    return default(T);
                }
                return queue.Dequeue();
            }
        }

        public void Enqueue(T item) {
            lock (syncRoot) {
                queue.Enqueue(item);
            }
        }

        public object SyncRoot {
            get { return syncRoot; }
        }

        public IEnumerator<T> GetEnumerator() {
            throw new NotImplementedException();
        }

        IEnumerator IEnumerable.GetEnumerator() {
            throw new NotImplementedException();
        }

        public void CopyTo(Array array, int index) {
            throw new NotImplementedException();
        }
    }
}
