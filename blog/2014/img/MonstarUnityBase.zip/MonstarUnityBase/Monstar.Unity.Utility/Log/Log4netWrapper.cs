﻿using log4net;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.U3D.Utility.Log {
    public static class Log4netWrapper {

        public static ILog D {
            get {
                ILog L = LogManager.GetLogger("default");
                if (L == null) {
                    throw new Exception("The log4net maybe doesn't be initialized!");
                }
                return L;
            }
        }


        public static void Configure() {
            // PC
            BasicConfigurator.Configure();

            // IPhone

            // Android

            // WindowsPhone

            // WebPlayer
        }

    }
}
