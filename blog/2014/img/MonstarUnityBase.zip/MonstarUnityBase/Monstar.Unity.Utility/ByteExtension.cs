﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Monstar.Unity.Utility {
    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :      

    //        created by unicorn(haiyin-ma) at  2013-5-29
    //
    //======================================================================

    public static class ByteExtension {
       
        public static short ToShort(byte[] data) {
            checkLength(data);
            return (short) toLong(data, 0, 2, 2);
        }

        public static ushort ToUShort(byte[] data) {
            checkLength(data);
            return (ushort) toLong(data, 0, 2, 2);
        }

        public static int ToInt(byte[] data) {
            checkLength(data);
            return (int) toLong(data, 0, 4, 4);
        }

        public static uint ToUInt(byte[] data) {
            checkLength(data);
            return (uint) toLong(data, 0, 4, 4);
        }

        public static String ByteArrayToHex(byte[] ba) {
            return ByteArrayToHex(ba, 0, ba.Length);
        }

        public static String ByteArrayToHex(byte[] ba, int offset) {
            return ByteArrayToHex(ba, 0, offset);
        }

        public static String ByteArrayToHex(byte[] ba, int start, int offset) {
            checkLength(ba);

            string hex = BitConverter.ToString(ba, start, offset);
            return hex.Replace("-", "");
        }

        public static byte[] HexToByteArray(string hex) {
            int NumberChars = hex.Length / 2;
            byte[] bytes = new byte[NumberChars];
            using (var sr = new StringReader(hex)) {
                for (int i = 0; i < NumberChars; i++)
                    bytes[i] = Convert.ToByte(
                        new string(new char[2] { (char) sr.Read(), (char) sr.Read() }), 16);
            }
            return bytes;
        }

        private static void checkLength(byte[] data) {
            if (data.Length == 0) {
                throw new ArgumentOutOfRangeException("data");
            }
        }

        private static long toLong(byte[] data, int offset, int count, int width) {
            if (width < 0 || width > 8) {
                throw new ArgumentOutOfRangeException("width", "width must between 1 and 8");
            }

            if (offset < 0 || offset > data.Length - 1) {
                throw new IndexOutOfRangeException();
            }

            if (count > 0) {
                if (offset + count > data.Length) {
                    count = data.Length - offset;
                }

                long result = 0;
                count = (count > width ? width : count);
                for (int i = offset; i < count + offset; i++) {
                    unchecked {
                        result += (data[i] << 8 * (count - 1 - i + offset));
                    }
                }

                return result;
            }

            throw new ArgumentOutOfRangeException("count", "count must be greater than 0");
        }
    }
}
