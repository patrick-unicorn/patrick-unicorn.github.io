﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.U3D.Utility {
    public class AttributeKey {

        private readonly string name;

        public AttributeKey(Type type, string name) {
            this.name = type.AssemblyQualifiedName 
                + "." + name 
                + "@" + this.GetHashCode().ToString("X");
        }

        public override string ToString() {
            return name;
        }

    }
}
