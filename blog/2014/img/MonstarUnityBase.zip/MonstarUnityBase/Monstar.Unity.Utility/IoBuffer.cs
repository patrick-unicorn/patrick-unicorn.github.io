﻿using System;
using System.Collections.Generic;

using System.Text;

namespace Monstar.Unity.Utility {
    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :      字节缓冲区对象，类似于JavaNIO IoBuffer。

    //        created by unicorn(haiyin-ma) at  2013-5-29
    //
    //======================================================================
    public class IoBuffer {

        public const int DEFAULT_SIZE = 4096;

        private int position = 0;

        private int limit = 0;

        private int capacity = 0;

        private byte[] buffer;

        private bool autoExpand = true;

        public byte[] Buffer {
            get { return buffer; }
        }

        public int Position {
            get { return position; }
            set { position = value; }
        }

        public int Limit {
            get { return limit; }
            set { limit = value; }
        }

        public int Capacity {
            get { return capacity; }
            private set {
                int newCapacity = value;

                if (newCapacity <= capacity) {
                    return;
                }

                byte[] newBuffer = new byte[newCapacity];
                Array.ConstrainedCopy(buffer, 0, newBuffer, 0, capacity);

                buffer = newBuffer;
                capacity = newCapacity;
            }
        }

        public int Remaining {
            get { return limit - position; }
        }

        public bool AutoExpand {
            get { return autoExpand; }
            set { autoExpand = value; }
        }

        protected IoBuffer(byte[] buffer) {
            if (buffer == null) {
                throw new ArgumentNullException("buffer");
            }

            capacity = limit = buffer.Length;

            this.buffer = buffer;
        }

        public static IoBuffer Allocate() {
            return Allocate(true);
        }

        public static IoBuffer Allocate(bool autoExpand) {
            return Allocate(DEFAULT_SIZE, autoExpand);
        }

        public static IoBuffer Allocate(int capacity) {
            return Allocate(capacity, true);
        }

        public static IoBuffer Allocate(int capacity, bool autoExpand) {
            if (capacity <= 0) {
                throw new ArgumentOutOfRangeException("capacity");
            }

            IoBuffer buf = new IoBuffer(new byte[capacity]);
            buf.AutoExpand = autoExpand;

            return buf;
        }

        public static IoBuffer Wrap(byte singleByte) {
            return IoBuffer.Wrap(new byte[] { singleByte });
        }

        public static IoBuffer Wrap(byte[] byteArray) {
            return Wrap(byteArray, 0, byteArray.Length);
        }

        public static IoBuffer Wrap(byte[] byteArray, int offset, int length) {
            IoBuffer buffer = IoBuffer.Allocate(length - offset);
            buffer.Put(byteArray, offset, length).Flip();

            return buffer;
        }

        public static IoBuffer Combine(IoBuffer buffer0, IoBuffer buffer1) {
            if (buffer0 == null || !buffer0.HasRemaining()) {
                return buffer1;
            }
            if (buffer1 == null || !buffer1.HasRemaining()) {
                return buffer0;
            }
            IoBuffer newBuffer = IoBuffer.Allocate(buffer0.Remaining + buffer1.Remaining);
            return newBuffer.Put(buffer0).Put(buffer1).Flip();
        }

        public bool HasRemaining() {
            return position < limit;
        }

        public IoBuffer Put(byte src) {
            Expand(1);

            buffer[position++] = src;

            limit = position;

            return this;
        }

        public IoBuffer Put(IoBuffer src) {
            if (src == this) {
                throw new ArgumentException("src");
            }

            int n = src.Remaining;
            Expand(n);

            Array.ConstrainedCopy(src.buffer, src.Position, buffer, Position, n);

            src.Position = src.Position + n;
            Position = Position + n;

            return this;
        }

        public IoBuffer Put(byte[] byteArray) {
            return Put(byteArray, 0, byteArray.Length);
        }
        
        public IoBuffer Put(byte[] src, int offset, int length) {
            CheckBounds(src, offset, length);

            Expand(length);

            if (length > Remaining) {
                throw new ArgumentException(
                    "buffer does not has enough remaining");
            }

            int end = offset + length;
            for (int i = offset; i < end; i++) {
                Put(src[i]);
            }

            return this;
        }

        /// <summary>
        /// 相对读
        /// </summary>
        /// <returns></returns>
        public byte Get() {
            return buffer[position++];
        }

        /// <summary>
        /// 绝对读
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public byte Get(int index) {
            if (index < 0 || index > limit) {
                throw new ArgumentOutOfRangeException("index");
            }

            return buffer[index];
        }

        /// <summary>
        /// 绝对读
        /// </summary>
        /// <param name="index"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        public byte[] Get(int index, int length) {
            CheckBounds(buffer, index, length);

            byte[] dest = new byte[length];
            Array.ConstrainedCopy(buffer, index, dest, 0, length);

            return dest;
        }

        /// <summary>
        /// 读取字节并填充到给定字节数组
        /// </summary>
        /// <param name="dest"></param>
        /// <returns></returns>
        public IoBuffer Get(byte[] dest) {
            return Get(dest, 0, dest.Length);
        }

        /// <summary>
        /// 读取字节并填充到给定字节数组
        /// </summary>
        /// <param name="dest"></param>
        /// <param name="offset"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        public IoBuffer Get(byte[] dest, int offset, int length) {
            CheckBounds(dest, offset, length);

            if (length > Remaining) {
                throw new ArgumentOutOfRangeException("length");
            }

            int end = offset + length;
            for (int i = offset; i < end; i++) {
                dest[i] = Get();
            }

            return this;
        }

        public string GetString(int fieldSize, Encoding decoding) {
            byte[] outBytes = new byte[fieldSize];
            Get(outBytes);
            return decoding.GetString(outBytes, 0, outBytes.Length);
        }

        /// <summary>
        /// 设置缓冲区position为0
        /// </summary>
        public IoBuffer Rewind() {
            position = 0;
            return this;
        }

        /// <summary>
        /// 设置缓冲区limit为position, 同时设置position为0
        /// </summary>
        public IoBuffer Flip() {
            limit = position;
            position = 0;
            return this;
        }

        /// <summary>
        /// 压缩缓冲区
        /// 
        /// 将position和limit之间的字节复制到缓冲区头部，复制后设置position为复制的字节数
        /// </summary>
        /// <returns></returns>
        public IoBuffer Compact() {
            int rem = Remaining;

            byte[] newBuffer = new byte[rem];
            Array.ConstrainedCopy(buffer, position, newBuffer, 0, rem);
            Array.Clear(buffer, 0, buffer.Length);
            Array.ConstrainedCopy(newBuffer, 0, buffer, 0, rem);

            limit = position = rem;
            return this;
        }

        /// <summary>
        /// 设置limit和position为0
        /// </summary>
        /// <returns></returns>
        public IoBuffer Clear() {
            position = limit = 0;
            return this;
        }

        private IoBuffer Expand(int expectedRemaining) {
            if (AutoExpand) {
                int newCapacity = Position + expectedRemaining;

                if (newCapacity > Capacity) {
                    Capacity = newCapacity;
                }

                if (newCapacity > Limit) {
                    Limit = newCapacity;
                }
            }

            return this;
        }

        private IoBuffer CheckBounds(byte[] dest, int offset, int length) {
            if (dest == null || dest.Length <= 0) {
                throw new ArgumentNullException("bytes");
            }

            if (offset < 0 || length < 0 
                || offset > dest.Length
                || length > dest.Length) {
                throw new ArgumentOutOfRangeException(
                    "offset and length must be greater than 0 and " +
                    "less than dest.Length");
            }

            if (offset + length > dest.Length) {
                throw new ArgumentOutOfRangeException(
                    "the sum of offset and length must be less than dest.Length");
            }

            return this;
        }
    }
}
