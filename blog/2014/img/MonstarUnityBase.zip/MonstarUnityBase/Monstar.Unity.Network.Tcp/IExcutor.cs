﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Threading;

namespace Monstar.Unity.Network.Tcp {

    /* ======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :      

    //        created by unicorn(haiyin-ma) at  2014-11-25
    //
    //====================================================================== */

    public interface IExcutor {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="task"></param>
        void Excute(WaitCallback task);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="task"></param>
        void Excute(WaitCallback task, object state);

    }
}
