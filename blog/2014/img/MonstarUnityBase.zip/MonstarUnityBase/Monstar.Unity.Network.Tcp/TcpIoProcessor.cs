﻿using Monstar.Unity.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-11-23
    //
    //======================================================================

    public class TcpIoProcessor : AbstractIOProcessor {

        private readonly int TRANSFER_SIZE = 1024 * 4;

        public TcpIoProcessor() : this(new SimpleThreadExcutor()) {

        }

        public TcpIoProcessor(IExcutor excutor) : base(excutor) {
            
        }

        protected override void DetectEvent() {
            if (CanWrite) {
                IRequestWrapper data = readySendingReqQueue.Dequeue();
                waitResponseReqQueue.Enqueue(data);
                Remoter.Processor.IOEventPublisher.FireIoWriteEvent(Remoter, data);
                return;
            }
            if (CanRead) {
                Read();
                return;
            }
            if (IsIdle) {
                Remoter.Processor.IOEventPublisher.FireIoIdleEvent(Remoter);
                return;
            }
        }

        private void Read() {
            SocketAsyncEventArgs socketAsyncEventArgs = new SocketAsyncEventArgs();
            socketAsyncEventArgs.Completed += new EventHandler<SocketAsyncEventArgs>(ReadCompleted);
            socketAsyncEventArgs.SetBuffer(new byte[TRANSFER_SIZE], 0, TRANSFER_SIZE);
            socketAsyncEventArgs.UserToken = Remoter;
            Remoter.Connector.UnderlyingSocket.ReceiveAsync(socketAsyncEventArgs);
        }

        private void ReadCompleted(object sender, SocketAsyncEventArgs e) {
            if (e.LastOperation == SocketAsyncOperation.Receive) {
                if (e.SocketError == SocketError.Success) {
                    IRemoter remoter = ((IRemoter) e.UserToken);
                    IOEventPublisher publisher = remoter.Processor.IOEventPublisher;
                    int bytesRead = e.BytesTransferred;
                    if (bytesRead > 0) {
                        LastIoReadTime = DateTimeExtension.CurrentTimeMillis;
                        remoter.L.Debug("RECV: BYTES=" + bytesRead
                            + " HEX=" + ByteExtension.ByteArrayToHex(e.Buffer, bytesRead));

                        IoBuffer packet = IoBuffer.Wrap(e.Buffer, 0, bytesRead);
                        publisher.FireIoReadEvent(remoter, new DefaultResponse(packet));
                    }
                } else {
                    throw new SocketException((int) e.SocketError);
                }
            }
        }

        public override void WritePacket(IoBuffer packet) {
            byte[] writeBuffer = new byte[packet.Remaining];
            packet.Get(writeBuffer);

            SocketAsyncEventArgs socketAsyncEventArgs = new SocketAsyncEventArgs();
            socketAsyncEventArgs.Completed += new EventHandler<SocketAsyncEventArgs>(WriteCompleted);
            socketAsyncEventArgs.UserToken = Remoter;
            socketAsyncEventArgs.SetBuffer(writeBuffer, 0, writeBuffer.Length);
            Remoter.Connector.UnderlyingSocket.SendAsync(socketAsyncEventArgs);
        }

        private void WriteCompleted(object sender, SocketAsyncEventArgs e) {
            if (e.LastOperation == SocketAsyncOperation.Send) {
                if (e.SocketError == SocketError.Success) {
                    IRemoter remoter = ((IRemoter) e.UserToken);
                    int bytesWrite = e.BytesTransferred;
                    if (bytesWrite > 0) {
                        LastIoWriteTime = DateTimeExtension.CurrentTimeMillis;
                        remoter.L.Debug("SENT: BYTES=" + bytesWrite
                            + " HEX=" + ByteExtension.ByteArrayToHex(e.Buffer, bytesWrite));
                    }
                } else {
                    throw new SocketException((int) e.SocketError);
                }
            }
        }
    }
}
