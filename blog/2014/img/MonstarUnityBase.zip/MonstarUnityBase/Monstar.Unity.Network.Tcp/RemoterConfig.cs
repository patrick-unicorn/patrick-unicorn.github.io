﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp {

    /* ======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :      

    //        created by unicorn(haiyin-ma) at  2014-11-25
    //
    //====================================================================== */

    public class RemoterConfig {

        /// <summary>
        /// 主机
        /// </summary>
        public string Host {
            get;
            set;
        }

        /// <summary>
        /// 端口
        /// </summary>
        public int Port {
            get;
            set;
        }

        private string charEncode = "utf-8";
        /// <summary>
        /// 编码
        /// </summary>
        public string CharEncode {
            get { return charEncode; }
            set { charEncode = value; }
        }

        private int ioFrequency = 100;
        /// <summary>
        /// IO事件泵频率
        /// </summary>
        public int IoFrequency {
            get { return ioFrequency; }
            set { ioFrequency = value; }
        }

        private int connectTimeout = 5 * 1000;
        /// <summary>
        /// 连接超时时间
        /// </summary>
        public int ConnectTimeout {
            get { return connectTimeout; }
            set { connectTimeout = value; }
        }

        private int recieveTimeout = 5 * 1000;
        /// <summary>
        /// 接受超时时间
        /// </summary>
        public int RecieveTimeout {
            get { return recieveTimeout; }
            set { recieveTimeout = value; }
        }

        private int sendTimeout = 5 * 1000;
        /// <summary>
        /// 发送超时时间
        /// </summary>
        public int SendTimeout {
            get { return sendTimeout; }
            set { sendTimeout = value; }
        }

        private int idleTimeSpan = 2 * 1000;
        /// <summary>
        /// IO无读写操作而触发Idle事件的时间间隔(毫秒)
        /// 
        /// <remarks>
        /// 两个限制：
        ///    1. 值应小于<code>keepAliveInerval</code>
        ///    2. 值应小于<code>keepAliveTimout</code>
        /// </remarks>
        /// </summary>
        public int IdleTimeSpan {
            get { return idleTimeSpan; }
            set { idleTimeSpan = value; }
        }

        private bool isKeepAlive = false;
        /// <summary>
        /// 是否开启长连接
        /// </summary>
        public bool IsKeepAlive {
            get { return isKeepAlive; }
            set { isKeepAlive = value; }
        }

        
        private int keepAliveInerval = 10;
        /// <summary>
        /// 心跳包发送频率
        /// </summary>
        public int KeepAliveInterval {
            get { return keepAliveInerval; }
            set { keepAliveInerval = value; }
        }

        private int keepAliveTimout = 20;
        /// <summary>
        /// 心跳包超时时间
        /// </summary>
        public int KeepAliveTimeout {
            get { return keepAliveTimout; }
            set { keepAliveTimout = value; }
        }

        private string reqHeartBeat = "@$";
        /// <summary>
        /// 请求心跳包
        /// </summary>
        public string ReqHeartBeat {
            get { return reqHeartBeat; }
            set { reqHeartBeat = value; }
        }

        private string resHeartBeat = "$@";
        /// <summary>
        /// 回复心跳包
        /// </summary>
        public string ResHeartBeat {
            get { return resHeartBeat; }
            set { resHeartBeat = value; }
        }

        private bool isCompress = true;
        /// <summary>
        /// 是否压缩数据
        /// </summary>
        public bool IsCompress {
            get { return isCompress; }
            set { isCompress = value; }
        }

        private int compressionLevel = 6;
        /// <summary>
        /// 压缩比
        /// </summary>
        public int CompressionLevel {
            get { return compressionLevel; }
            set { compressionLevel = value; }
        }

        private bool isEncrypt = true;
        /// <summary>
        /// 是否加密数据
        /// </summary>
        public bool IsEncrypt {
            get { return isEncrypt; }
            set { isEncrypt = value; }
        }

        /// <summary>
        /// 公钥
        /// </summary>
        public string EncryptPublicKey {
            get;
            set;
        }

        /// <summary>
        /// 私钥
        /// </summary>
        public string EncryptPrivateKey {
            get;
            set;
        }

        /// <summary>
        /// 加解密IV变量
        /// </summary>
        public string EncryptIVParamter {
            get;
            set;
        }

        private int sendBufferSize = 1024 * 8;
        /// <summary>
        /// socket发送缓冲区大小
        /// </summary>
        public int SendBufferSize {
            get { return sendBufferSize; }
            set { sendBufferSize = value; }
        }

        private int recieveBufferSize = 1024 * 8;
        /// <summary>
        /// socket接受缓冲区大小
        /// </summary>
        public int RecieveBufferSize {
            get { return recieveBufferSize; }
            set { recieveBufferSize = value; }
        }

        private int maxTransferSize = 1024 * 4;
        /// <summary>
        /// socket单次最大传输数据
        /// </summary>
        public int MaxTransferSize {
            get { return maxTransferSize; }
            set { maxTransferSize = value; }
        }

        private bool turnOnPing = false;
        /// <summary>
        /// 是否开启PING
        /// </summary>
        public bool TurnOnPing {
            get { return turnOnPing; }
            set { turnOnPing = value; }
        }

        private string pingData = "ping";
        /// <summary>
        /// PING数据
        /// </summary>
        public string PingData {
            get { return pingData; }
            set { pingData = value; }
        }

        private int pingTimeout = 300;
        /// <summary>
        /// PING超时时间(毫秒)
        /// </summary>
        public int PingTimeout {
            get { return pingTimeout; }
            set { pingTimeout = value; }
        }

        private int pingFrequecy = 15;
        /// <summary>
        /// PING超时时间(秒)
        /// </summary>
        public int PingFrequecy {
            get { return pingFrequecy; }
            set { pingFrequecy = value; }
        }

    }
}
