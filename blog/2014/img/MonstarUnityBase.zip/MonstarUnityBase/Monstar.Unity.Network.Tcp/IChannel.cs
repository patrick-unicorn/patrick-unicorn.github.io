﻿using Monstar.U3D.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp {

    /* ======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :      

    //        created by unicorn(haiyin-ma) at  2014-11-25
    //
    //====================================================================== */

    /// <summary>
    /// 单个频道消息处理委托
    /// </summary>
    /// <param name="channel"></param>
    /// <param name="message"></param>
    public delegate void ChannelMessageHandler(IChannel channel, object message);

    /// <summary>
    /// 频道接口
    /// </summary>
    public interface IChannel {

        /// <summary>
        /// 频道ID
        /// </summary>
        object ID { get; }

        /// <summary>
        /// 频道名字
        /// </summary>
        string Name { get; set; }

        /// <summary>
        /// 是否有消息
        /// </summary>
        bool HaveMessage { get; }

        /// <summary>
        /// 是否当前频道消息
        /// 
        /// <remarks>实现者应保证每种消息只能被一个频道判别</remarks>
        /// </summary>
        bool IsChannelMessage(object message);

        /// <summary>
        /// 频道消息队列
        /// </summary>
        ConcurrencyQueue<object> MessageQueue { get; }

        /// <summary>
        /// 频道消息处理委托
        /// </summary>
        ChannelMessageHandler ChannelHandler { get; set; }

        /// <summary>
        /// 处理频道消息
        /// 
        /// 内部可以简单调用<code>ChannelHandler</code>，亦可添加自定义逻辑。
        /// 典型的应用场景：在游戏主循环中调用该方法处理频道消息，如Chat等。
        /// </summary>
        /// <param name="state"></param>
        void ProcessMessage(object state);

    }
}
