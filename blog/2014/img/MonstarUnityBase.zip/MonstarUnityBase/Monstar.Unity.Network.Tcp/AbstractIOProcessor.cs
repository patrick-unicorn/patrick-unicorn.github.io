﻿using Monstar.U3D.Utility;
using Monstar.U3D.Utility.Log;
using Monstar.Unity.Utility;
using System;
using System.Collections.Generic;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-11-23
    //
    //======================================================================

    /// <summary>
    /// 抽象IO事件循环处理器
    /// </summary>
    public abstract class AbstractIOProcessor : IOProcessor, IOEventPublisher {

        private Ping ping = new Ping();

        private Int64 lastPingTime = 0;

        private IExcutor excutor;

        /// <summary>
        /// 等待发送的请求队列
        /// </summary>
        protected ConcurrencyQueue<IRequestWrapper> readySendingReqQueue;

        /// <summary>
        /// 等待响应的请求队列
        /// </summary>
        protected ConcurrencyQueue<IRequestWrapper> waitResponseReqQueue;

        public AbstractIOProcessor(IExcutor excutor) {
            this.excutor = excutor;
            this.readySendingReqQueue = new ConcurrencyQueue<IRequestWrapper>();
            this.waitResponseReqQueue = new ConcurrencyQueue<IRequestWrapper>();

            ping.PingCompleted += delegate(object sender, PingCompletedEventArgs e) {
                if (e.Reply != null) {
                    IRemoter remoter = null;
                    try {
                        remoter = (IRemoter) e.UserState;
                        remoter.L.Debug(string.Format("PING: host={0}, state={1}, time={2}",
                                        e.Reply.Address, e.Reply.Status, e.Reply.RoundtripTime));
                        if (e.Reply.Status == IPStatus.Success) {
                            remoter.Ping = e.Reply.RoundtripTime;
                        }
                    } catch (Exception ex) {
                        if (remoter != null) {
                            remoter.HandleException(ex, "Ping");
                        }
                        Log4netWrapper.D.Error("Ping Completed Error", ex);
                    }
                }
            };
        }

        /// <summary>
        /// IO时间泵
        /// </summary>
        /// <param name="state"></param>
        public void Loop(object state) {
            Remoter.L.Debug("I/O-Processor was started!");
            while (true) {
                try {
                    if (Remoter.IsStoped) {
                        Dispose();
                        break;
                    }
                    if (Remoter.Configure.TurnOnPing) {
                        ComputeAndUpdatePingValue();
                    }

                    DetectEvent();
                    Thread.Sleep(Remoter.Configure.IoFrequency);
                } catch (Exception e) {
                    Remoter.Stop(null);
                    Remoter.HandleException(e, "I/O-Processor");
                }
            }
        }

        protected abstract void DetectEvent();

        
        /// <summary>
        /// 计算并更新当前连接PING值
        /// </summary>
        private void ComputeAndUpdatePingValue() {
            long currTime = DateTimeExtension.CurrentTimeMillis;
            long interval = Remoter.Configure.PingFrequecy * 1000;
            bool isPing = lastPingTime == 0 || (currTime - lastPingTime > interval);

            if (isPing) {
                lastPingTime = DateTimeExtension.CurrentTimeMillis;
                ping.SendAsync(Remoter.Configure.Host, Remoter.Configure.PingTimeout, Remoter);
            }
        }

        #region IoProcessor

        public IRemoter Remoter {
            get;
            set;
        }

        public IExcutor Excutor {
            get { return excutor; }
        }

        public IOEventPublisher IOEventPublisher {
            get { return this; }
        }

        public void Run() {
            excutor.Excute(Loop, Remoter);
        }

        public void WriteRequest(IRequestWrapper request) {
            readySendingReqQueue.Enqueue(request);
        }

        public IRequestWrapper ReadRequest() {
            return waitResponseReqQueue.Dequeue();
        }

        public virtual void WritePacket(IoBuffer packet) {
            // NOP.
        }

        public void Dispose() {
            Remoter.L.Debug("I/O-Processor was stoped!");
        }

        public bool IsIdle {
            get {
                long lastIoTime =
                    (LastIoWriteTime > LastIoReadTime) ? LastIoWriteTime : LastIoReadTime;
                long currTime = DateTimeExtension.CurrentTimeMillis;
                return (currTime - lastIoTime > Remoter.Configure.IdleTimeSpan);
            }
        }

        private long lastIoReadTime;
        public long LastIoReadTime {
            get { return lastIoReadTime; }
            set {
                if (lastIoReadTime > DateTimeExtension.CurrentTimeMillis) {
                    throw new ArgumentOutOfRangeException("lastIoReadTime");
                }
                lastIoReadTime = value;
            }
        }

        private long lastIoWriteTime;
        public long LastIoWriteTime {
            get { return lastIoWriteTime; }
            set {
                if (lastIoWriteTime > DateTimeExtension.CurrentTimeMillis) {
                    throw new ArgumentOutOfRangeException("lastIoWriteTime");
                }
                lastIoWriteTime = value; 
            }
        }

        public bool CanRead {
            get {
                return Remoter.Connector.UnderlyingSocket.Connected
                    && (Remoter.Connector.UnderlyingSocket.Available > 0);
            }
        }

        public bool CanWrite {
            get {
                return Remoter.Connector.UnderlyingSocket.Connected
                    && (readySendingReqQueue.Count > 0);
            }
        }

        #endregion

        #region IOEventPublisher

        public event IoWriteHandler IoWriteEvent;

        public event IoReadHandler IoReadEvent;

        public event IoIdleHandler IoIdleEvent;

        public void FireIoWriteEvent(IRemoter remoter, IRequestWrapper packet) {
            remoter.IOEventHandlerChainBuilder.HandlerChain.Tail.HandleIoWriteEvent(remoter, packet);
        }

        public void FireIoReadEvent(IRemoter remoter, IResponseWrapper packet) {
            remoter.IOEventHandlerChainBuilder.HandlerChain.Head.HandleIoReadEvent(remoter, packet);
        }

        public void FireIoIdleEvent(IRemoter remoter) {
            remoter.IOEventHandlerChainBuilder.HandlerChain.Head.HandleIoIdleEvent(remoter);
        }

        #endregion

    }
}
