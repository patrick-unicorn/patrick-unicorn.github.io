﻿using log4net;
using Monstar.U3D.Utility;
using Monstar.U3D.Utility.Log;
using Monstar.Unity.Utility;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp {

    /* ======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :      

    //        created by unicorn(haiyin-ma) at  2014-11-25
    //
    //====================================================================== */

    public class AbstractRemoter : IRemoter {

        private ILog logger = Log4netWrapper.D;
        public ILog L {
            get { return logger; }
            set { this.logger = value; }
        }

        /// <summary>
        /// 属性字典
        /// </summary>
        private IDictionary<object, object> attributes;

        private object stopSyncRoot = new object();
        private bool isStoped;
        public bool IsStoped {
            get {
                lock (stopSyncRoot) {
                    return isStoped;
                }
            }
            private set {
                lock (stopSyncRoot) {
                    isStoped = value;
                }
            }
        }

        public long Ping {
            get;
            set;
        }

        public long StartTime {
            get;
            private set;
        }

        private IConnector connector;
        public IConnector Connector {
            get { return connector; }
        }

        private IOProcessor processor;
        public IOProcessor Processor {
            get { return processor; }
        }

        public RemoterConfig Configure {
            get;
            set;
        }

        public IDataHandler DataHandler {
            get;
            set;
        }

        public ExceptionCaught ExceptionHandler {
            private get;
            set;
        }

        private IOEventHandlerChainBuilder ioEventHandlerChainBuilder;
        public IOEventHandlerChainBuilder IOEventHandlerChainBuilder {
            get { return ioEventHandlerChainBuilder; }
        }

        public AbstractRemoter(IConnector connector, IOProcessor processor) {
            this.connector = connector;
            this.processor = processor;
            this.attributes = new Dictionary<object, object>();
            this.ioEventHandlerChainBuilder = 
                new DefaultIOEventHandlerChainBuilder(processor.IOEventPublisher);
            this.connector.Remoter = this;
            this.processor.Remoter = this;
        }

        public void Start(object state) {
            if (Connector.Connect()) {
                StartTime = DateTimeExtension.CurrentTimeMillis;
                Processor.Run();
            }
        }

        public void Stop(object state) {
            IsStoped = true;
            connector.UnderlyingSocket.Close();
        }

        public object Request(object request) {
            return Request(request, -1);
        }

        public object Request(object request, int timeout) {
            ManualResetEvent syncWaitHandle = AsyncRequest(request, null);
            syncWaitHandle.WaitOne(timeout);

            IAsyncCallbackTask callbackTask = DataHandler.LatestCallBackTask;
            if (callbackTask == null) {
                throw new TimeoutException("Request");
            }
            return callbackTask.AsyncResult;
        }

        public object Request(object request, MSyncCallback syncCallback, int timeout) {
            ManualResetEvent syncWaitHandle = AsyncRequest(request, null);
            syncWaitHandle.WaitOne(timeout);

            IAsyncCallbackTask callbackTask = DataHandler.LatestCallBackTask;
            if (callbackTask == null) {
                throw new TimeoutException("Request");
            }
            syncCallback(callbackTask.AsyncResult, this);
            return callbackTask.AsyncResult;
        }

        public ManualResetEvent AsyncRequest(object request, MAsyncCallback callback) {
            IRequestWrapper wRequest = new DefaultRequest(request);
            wRequest.ResponseTask.WaitHandle = new ManualResetEvent(false);
            wRequest.ResponseTask.MethodHandle = callback;
            Processor.WriteRequest(wRequest);
            return wRequest.ResponseTask.WaitHandle;
        }

        public void PushOutMessage(object message) {
            Processor.WriteRequest(new DefaultRequest(message, false));
        }

        public void Subscribe(IChannel channel) {
            DataHandler.RegisterChannel(channel);
        }

        public object GetAttribute(object key) {
            lock (attributes) {
                if (attributes.ContainsKey(key)) {
                    return attributes[key];
                }
                return null;
            }
        }

        public bool RemoveAttribute(object key) {
            lock (attributes) {
                return attributes.Remove(key);
            }
        }

        public void AddAttribute(object key, object attr) {
            lock (attributes) {
                attributes.Remove(key);
                attributes.Add(key, attr);
            }
        }

        public bool AddAttributeIfAbsent(object key, object attr) {
            lock (attributes) {
                if (!attributes.ContainsKey(key)) {
                    attributes.Add(key, attr);
                    return true;
                }
                return false;
            }
        }

        public void HandleException(Exception innerE, object state) {
            try {
                ExceptionHandler(innerE, state);
            } catch(Exception e) {
                L.Error("New Exception happened when handling an inner-exception: ", e);
                L.Error(string.Format("The original exception: state={0}", state), innerE);
            }
        }

    }
}
