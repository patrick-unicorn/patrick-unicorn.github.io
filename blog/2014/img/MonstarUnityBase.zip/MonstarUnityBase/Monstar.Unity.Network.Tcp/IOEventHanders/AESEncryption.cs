﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp.IOEventHanders {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-12-1
    //
    //======================================================================

    public class AESFactory : IEncryptionFactory {

        private IEncrypter encrypter;
        public IEncrypter Encrypter {
            get { return encrypter; }
        }

        private IDecrypter decrypter;
        public IDecrypter Decrypter {
            get { return decrypter; }
        }

        public AESFactory(string key, string iv) {
            this.encrypter = new AESEncrypter(key, iv);
            this.decrypter = new AESDecrypter(key, iv);
        }

    }

    public class AESEncrypter : IEncrypter {

        private string key;

        private string iv;

        public AESEncrypter(string key, string iv) {
            this.key = key;
            this.iv = iv;
        }

        public byte[] Encrypt(byte[] inBytes) {
            try {
                AesManaged aes = new AesManaged();
                ICryptoTransform encryptor = 
                    aes.CreateEncryptor(Encoding.UTF8.GetBytes(key), Encoding.UTF8.GetBytes(iv));
                return encryptor.TransformFinalBlock(inBytes, 0, inBytes.Length);
            } catch (Exception e) {
                throw e;
            }
        }

    }

    public class AESDecrypter : IDecrypter {

        private string key;

        private string iv;

        public AESDecrypter(string key, string iv) {
            this.key = key;
            this.iv = iv;
        }

        public byte[] Decrypt(byte[] inBytes) {
            try {
                AesManaged aes = new AesManaged();
                ICryptoTransform decryptor =
                    aes.CreateDecryptor(Encoding.UTF8.GetBytes(key), Encoding.UTF8.GetBytes(iv));
                return decryptor.TransformFinalBlock(inBytes, 0, inBytes.Length);
            } catch (Exception e) {
                throw e;
            }
        }

    }
}
