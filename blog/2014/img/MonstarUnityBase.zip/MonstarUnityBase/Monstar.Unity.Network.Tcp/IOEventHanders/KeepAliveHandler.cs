﻿using Monstar.Unity.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp.IOEventHanders {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-11-23
    //
    //======================================================================

    public interface KeepAlivePacketFactory {

        /// <summary>
        /// 判断是否(发送的)心跳请求包
        /// </summary>
        /// <param name="remoter"></param>
        /// <param name="packet"></param>
        /// <returns></returns>
        bool IsRequest(IRemoter remoter, object packet);

        /// <summary>
        /// 判断是否(接收的)心跳响应包
        /// </summary>
        /// <param name="remoter"></param>
        /// <param name="packet"></param>
        /// <returns></returns>
        bool IsResponse(IRemoter remoter, object packet);

        /// <summary>
        /// 获取心跳请求包
        /// </summary>
        /// <param name="remoter"></param>
        /// <returns></returns>
        object GetRequest(IRemoter remoter);

        /// <summary>
        /// 获取心跳响应包
        /// </summary>
        /// <param name="remoter"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        object GetResponse(IRemoter remoter, object request);

    }

    public delegate void KeepAliveTimeoutHandler(IRemoter remoter);

    /// <summary>
    /// 长连接心跳包处理器
    /// </summary>
    public class KeepAliveHandler : IOEventHandler {

        /// <summary>
        /// 是否在等待心跳回复包
        /// </summary>
        private bool isWaitingResponse;

        /// <summary>
        /// 上次发送心跳的时间点
        /// </summary>
        private long lastHBSentTime;

        private KeepAlivePacketFactory factory;

        private KeepAliveTimeoutHandler timeoutHandler;

        public IOEventHandler PrevHander {
            get;
            set;
        }

        public IOEventHandler NextHander {
            get;
            set;
        }

        private int timeout;
        /// <summary>
        /// 心跳超时时间(毫秒)
        /// </summary>
        public int Timeout {
            get { return timeout; }
            private set {
                if (value < 0) {
                    throw new ArgumentException("timeout");
                }
                timeout = value * 1000;
            }
        }

        private int interval;
        /// <summary>
        /// 心跳频率(毫秒)
        /// </summary>
        public int Interval {
            get { return interval; }
            private set {
                if (value < 0) {
                    throw new ArgumentException("interval");
                }
                interval = value * 1000;
            }
        }

        public KeepAliveHandler(int interval, int timeout,
            KeepAlivePacketFactory packetFactory, KeepAliveTimeoutHandler timeoutHandler) 
        {
            if (packetFactory == null) {
                throw new ArgumentNullException("messageFactory");
            }

            if (timeoutHandler == null) {
                throw new ArgumentNullException("timeoutHandler");
            }

            this.factory = packetFactory;
            this.timeoutHandler = timeoutHandler;
            this.Interval = interval;
            this.Timeout = timeout;
        }

        /// <summary>
        /// 心跳包不需外部发送写入
        /// </summary>
        /// <param name="remoter"></param>
        /// <param name="packet"></param>
        /// <returns></returns>
        public void HandleIoWriteEvent(IRemoter remoter, IRequestWrapper data) {
            PrevHander.HandleIoWriteEvent(remoter, data);
        }

        /// <summary>
        /// 读数据包并判断是否为心跳包
        /// </summary>
        /// <param name="remoter"></param>
        /// <param name="packet"></param>
        /// <returns></returns>
        public void HandleIoReadEvent(IRemoter remoter, IResponseWrapper data) {
            if (data != null && data.Data != null) {
                long currTime = DateTimeExtension.CurrentTimeMillis;

                IoBuffer buffer = data.Data as IoBuffer;
                if (buffer == null) {
                    throw new ArgumentNullException("data.Data");
                }

                try {
                    if (factory.IsRequest(remoter, buffer)) {
                        IoBuffer response = factory.GetResponse(remoter, buffer) as IoBuffer;
                        remoter.Processor.WritePacket(response);
                    }
                    if (factory.IsResponse(remoter, buffer)) {
                        HandleTimeout(currTime, remoter);
                        isWaitingResponse = false;
                    }
                } finally {
                    if (!(factory.IsRequest(remoter, buffer) 
                            || factory.IsResponse(remoter, buffer))) {
                        NextHander.HandleIoReadEvent(remoter, data);
                    }
                }
            }
        }

        /// <summary>
        /// 根据心跳频率判断是否在事件函数中发送心跳包
        /// </summary>
        /// <param name="remoter"></param>
        public void HandleIoIdleEvent(IRemoter remoter) {
            long currTime = DateTimeExtension.CurrentTimeMillis;
            if (!isWaitingResponse) {
                long actualInterval = lastHBSentTime == 0 ? currTime - remoter.StartTime 
                                                          : currTime - lastHBSentTime;
                if (actualInterval > interval) {
                    object request = factory.GetRequest(remoter);
                    remoter.Processor.WritePacket((IoBuffer) request);

                    isWaitingResponse = true;
                    lastHBSentTime = currTime;
                }
            } else {
                HandleTimeout(currTime, remoter);
            }
        }

        private void HandleTimeout(long currTime, IRemoter remoter) {
            if (lastHBSentTime != 0 && currTime - lastHBSentTime > timeout) {
                timeoutHandler(remoter);
            }
        }

    }
}
