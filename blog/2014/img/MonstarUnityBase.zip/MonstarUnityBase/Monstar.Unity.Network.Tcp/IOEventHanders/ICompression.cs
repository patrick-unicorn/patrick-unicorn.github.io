﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp {

    /* ======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :      

    //        created by unicorn(haiyin-ma) at  2014-11-25
    //
    //====================================================================== */

    public interface ICompressor {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inBuffer"></param>
        /// <returns></returns>
        byte[] Compress(byte[] inBytes);

    }

    public interface IDecompressor {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inBuffer"></param>
        /// <returns></returns>
        byte[] Decompress(byte[] inBytes);

    }

    public interface ICompressionFactory {

        ICompressor Compressor { get; }

        IDecompressor Decompressor { get; }

    }

}
