﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp.IOEventHanders {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-12-1
    //
    //======================================================================

    public interface ISerialize {

        object Serialize(IRemoter remoter, object data);
    }

    public interface IDeserialize {

        object DeSerialize(IRemoter remoter, object data);
    }

    public interface ISerializationFactory {

        ISerialize Serializer { get; }

        IDeserialize Deserializer { get; }

    }
}
