﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp.IOEventHanders {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-12-1
    //
    //======================================================================

    /// <summary>
    /// 压缩/解压缩处理器
    /// </summary>
    public class CompressionHandler : IOEventHandler {

        private ICompressionFactory factory;

        public IOEventHandler PrevHander {
            get;
            set;
        }

        public IOEventHandler NextHander {
            get;
            set;
        }

        public CompressionHandler(ICompressionFactory compressionFactory) {
            this.factory = compressionFactory;
        }

        public void HandleIoWriteEvent(IRemoter remoter, IRequestWrapper data) {
            byte[] bytes = factory.Compressor.Compress(TryConvertData(data.Data));
            PrevHander.HandleIoWriteEvent(remoter, data.New(bytes));
        }

        public void HandleIoReadEvent(IRemoter remoter, IResponseWrapper data) {
            byte[] bytes = factory.Decompressor.Decompress(TryConvertData(data.Data));
            NextHander.HandleIoReadEvent(remoter, data.New(bytes));
        }

        public void HandleIoIdleEvent(IRemoter remoter) {
            NextHander.HandleIoIdleEvent(remoter);
        }

        private byte[] TryConvertData(object data) {
            byte[] bytes = data as byte[];
            if (bytes == null || bytes.Length <= 0) {
                throw new ArgumentNullException("data");
            }
            return bytes;
        }

    }
}
