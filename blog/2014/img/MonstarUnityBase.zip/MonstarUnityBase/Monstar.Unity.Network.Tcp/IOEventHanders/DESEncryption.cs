﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp.IOEventHanders {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-12-1 10:31:09
    //
    //======================================================================

    public class DESFactory : IEncryptionFactory {

        private IEncrypter encrypter;
        public IEncrypter Encrypter {
            get { return encrypter; }
        }

        private IDecrypter decrypter;
        public IDecrypter Decrypter {
            get { return decrypter; }
        }

        public DESFactory(string key) {
            this.encrypter = new DESEncrypter(key);
            this.decrypter = new DESDEcrypter(key);
        }

    }

    public class DESEncrypter : IEncrypter {

        private string key;

        public string Key {
            get { return key; }
            set {
                if (Encoding.UTF8.GetBytes(value).Length != 8) {
                    throw new ArgumentException("key");
                }
                this.key = value;
            }
        }

        public DESEncrypter(string key) {
            this.Key = key;
        }

        #region IEncrypter Members

        public byte[] Encrypt(byte[] inBytes) {
            try {
                DESCryptoServiceProvider desc = new DESCryptoServiceProvider();
                desc.Padding = PaddingMode.PKCS7;
                desc.Mode = CipherMode.ECB;
                desc.IV = Encoding.UTF8.GetBytes(key);
                desc.Key = Encoding.UTF8.GetBytes(key);

                return desc.CreateEncryptor().TransformFinalBlock(inBytes, 0, inBytes.Length);
            } catch(Exception e) {
                throw e;
            }
        }

        #endregion

    }

    public class DESDEcrypter : IDecrypter {

        private string key;

        public string Key {
            get { return key; }
            set {
                if (Encoding.UTF8.GetBytes(value).Length != 8) {
                    throw new ArgumentException("key");
                }
                this.key = value;
            }
        }

        public DESDEcrypter(string key) {
            this.Key = key;
        }

        #region IDecrypter Members

        public byte[] Decrypt(byte[] inBytes) {
            try {
                DESCryptoServiceProvider desc = new DESCryptoServiceProvider();
                desc.Padding = PaddingMode.PKCS7;
                desc.Mode = CipherMode.ECB;
                desc.IV = Encoding.UTF8.GetBytes(key);
                desc.Key = Encoding.UTF8.GetBytes(key);

                return desc.CreateDecryptor().TransformFinalBlock(inBytes, 0, inBytes.Length);
            } catch (Exception e) {
                throw e;
            }
        }

        #endregion

    }
}
