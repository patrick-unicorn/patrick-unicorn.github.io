﻿using Monstar.Unity.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp.IOEventHanders {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-12-1
    //
    //======================================================================

    public interface IPacker {

        IoBuffer Pack(IRemoter remoter, object data);

    }

    public interface IUnPacker {

        object UnPack(IRemoter remoter, IoBuffer buffer);

    }

    public interface IPackageFactory {

        IPacker Packer { get; }

        IUnPacker UnPacker { get; }

    }

}
