﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp.IOEventHanders {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-12-1
    //
    //======================================================================

    public class SerializationHandler : IOEventHandler {

        private ISerializationFactory factory;

        public IOEventHandler PrevHander {
            get;
            set;
        }

        public IOEventHandler NextHander {
            get;
            set;
        }

        public SerializationHandler(ISerializationFactory serializationFactory) {
            this.factory = serializationFactory;
        }

        public void HandleIoWriteEvent(IRemoter remoter, IRequestWrapper data) {
            object retObj = factory.Serializer.Serialize(remoter, data);
            PrevHander.HandleIoWriteEvent(remoter, data.New(retObj));
        }

        public void HandleIoReadEvent(IRemoter remoter, IResponseWrapper data) {
            object retObj = factory.Deserializer.DeSerialize(remoter, data);
            NextHander.HandleIoReadEvent(remoter, data.New(retObj));
        }

        public void HandleIoIdleEvent(IRemoter remoter) {
            NextHander.HandleIoIdleEvent(remoter);
        }
    }
}
