﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp.IOEventHanders {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-12-1
    //
    //======================================================================

    /// <summary>
    /// 加密/解密处理器
    /// </summary>
    public class EncryptionHandler : IOEventHandler {

        private IEncryptionFactory factory;

        public IOEventHandler PrevHander {
            get;
            set;
        }

        public IOEventHandler NextHander {
            get;
            set;
        }

        public EncryptionHandler(IEncryptionFactory encryptionFactory) {
            this.factory = encryptionFactory;
        }

        public void HandleIoWriteEvent(IRemoter remoter, IRequestWrapper data) {
            byte[] bytes = factory.Encrypter.Encrypt(TryConvertData(data.Data));
            PrevHander.HandleIoWriteEvent(remoter, data.New(bytes));
        }

        public void HandleIoReadEvent(IRemoter remoter, IResponseWrapper data) {
            byte[] bytes = factory.Decrypter.Decrypt(TryConvertData(data.Data));
            NextHander.HandleIoReadEvent(remoter, data.New(bytes));
        }

        public void HandleIoIdleEvent(IRemoter remoter) {
            NextHander.HandleIoIdleEvent(remoter);
        }

        private byte[] TryConvertData(object data) {
            byte[] bytes = data as byte[];
            if (bytes == null || bytes.Length <= 0) {
                throw new ArgumentNullException("data");
            }
            return bytes;
        }

    }
}
