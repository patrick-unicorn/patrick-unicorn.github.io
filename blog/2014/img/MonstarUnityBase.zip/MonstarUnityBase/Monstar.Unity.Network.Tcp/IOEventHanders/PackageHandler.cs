﻿using Monstar.U3D.Utility;
using Monstar.Unity.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp.IOEventHanders {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-11-23 10:31:09
    //
    //======================================================================

    /// <summary>
    /// 封包/解包处理器
    /// </summary>
    public class PackageHandler : IOEventHandler {

        private IPackageFactory factory;

        public PackageHandler(IPackageFactory packageFactory) {
            this.factory = packageFactory;
        }

        public IOEventHandler PrevHander {
            get;
            set;
        }

        public IOEventHandler NextHander {
            get;
            set;
        }

        public void HandleIoWriteEvent(IRemoter remoter, IRequestWrapper data) {
            IoBuffer buffer = factory.Packer.Pack(remoter, data.Data);
            PrevHander.HandleIoWriteEvent(remoter, data.New(buffer));
        }

        public void HandleIoReadEvent(IRemoter remoter, IResponseWrapper data) {
            IoBuffer buffer = data.Data as IoBuffer;
            if (buffer == null) {
                throw new ArgumentException("Data must be IoBuffer!");
            }
            object message = factory.UnPacker.UnPack(remoter, buffer);
            if (!message.Equals(-1)) {
                NextHander.HandleIoReadEvent(remoter, data.New(message));
            }
        } 

        public void HandleIoIdleEvent(IRemoter remoter) {
            NextHander.HandleIoIdleEvent(remoter);
        }

    }

    public abstract class CumulatedUnPacker : IUnPacker {

        /// <summary>
        /// 不完整的二进制包数据键
        /// </summary>
        static readonly AttributeKey K_B = new AttributeKey(typeof(CumulatedUnPacker), "partial");

        /// <summary>
        /// 完整的解包对象键
        /// </summary>
        static readonly AttributeKey K_O = new AttributeKey(typeof(CumulatedUnPacker), "whole");

        public object UnPack(IRemoter remoter, IoBuffer buffer) {
            IoBuffer partials = remoter.GetAttribute(K_B) as IoBuffer;
            partials = IoBuffer.Combine(partials, buffer);
            remoter.AddAttribute(K_B, partials);

            if (DoUnPack(remoter, partials)) {
                partials.Compact();
                partials.Rewind();
                return remoter.GetAttribute(K_O);
            }
            return -1;
        }

        /// <summary>
        /// 解包
        /// </summary>
        /// <param name="remoter"></param>
        /// <param name="buffer"></param>
        /// <returns>
        /// true  - 可解包
        /// false - 不可解包，即包还不完整
        /// </returns>
        protected abstract bool DoUnPack(IRemoter remoter, IoBuffer buffer);

        /// <summary>
        /// 存储解包完毕的包对象
        /// </summary>
        /// <param name="remoter"></param>
        /// <param name="packetObj"></param>
        protected void StorePacket(IRemoter remoter, object packetObj) {
            remoter.AddAttribute(K_O, packetObj);
        }
    }
}
