﻿using ComponentAce.Compression.Libs.zlib;
using Monstar.Unity.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp.IOEventHanders {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-11-23
    //
    //======================================================================

    public class ZIPFactory : ICompressionFactory {

        private ICompressor compressor;
        public ICompressor Compressor {
            get { return compressor; }
        }

        private IDecompressor decompressor;
        public IDecompressor Decompressor {
            get { return decompressor; }
        }

        public ZIPFactory() {
            compressor = new ZIPCompressor();
            decompressor = new ZIPDecompressor();
        }

    }

    public class ZIPCompressor : ICompressor {

        private int compressLevel;

        public ZIPCompressor() : this(9) {

        }

        public ZIPCompressor(int compressLevel) {
            this.compressLevel = compressLevel;
        }

        public byte[] Compress(byte[] inBytes) {
            if (inBytes == null || inBytes.Length <= 0) {
                throw new ArgumentNullException("inBytes");
            }

            ZStream zStream = new ZStream();
            zStream.deflateInit(9);

            // according to spec, destination buffer should be 0.1% larger
            // than source length plus 12 bytes. We add a single byte to safeguard
            // against rounds that round down to the smaller value
            int outLen = (int) Math.Round(inBytes.Length * 1.001) + 1 + 12;
            byte[] outBytes = new byte[outLen];

            zStream.next_in = inBytes;
            zStream.next_in_index = 0;
            zStream.avail_in = inBytes.Length;
            zStream.next_out = outBytes;
            zStream.next_out_index = 0;
            zStream.avail_out = outBytes.Length;

            int retval = zStream.deflate(zlibConst.Z_SYNC_FLUSH);
            if (retval != zlibConst.Z_OK) {
                outBytes = null;
                inBytes = null;
                throw new Exception("Compression failed with return value : " + retval);
            }

            byte[] retBytes = new byte[zStream.next_out_index];
            Array.ConstrainedCopy(outBytes, 0, retBytes, 0, zStream.next_out_index);

            zStream.free();
            return retBytes;
        }

    }

    public class ZIPDecompressor : IDecompressor {

        public byte[] Decompress(byte[] inBytes) {
            if (inBytes == null || inBytes.Length <= 0) {
                throw new ArgumentNullException("inBytes");
            }

            ZStream zStream = new ZStream();
            zStream.inflateInit();

            // We could probably do this better, if we're willing to return multiple buffers
            // (e.g. with a callback function)
            byte[] outBytes = new byte[inBytes.Length * 2];
            IoBuffer outBuffer = IoBuffer.Allocate(outBytes.Length);
            outBuffer.AutoExpand = true;

            zStream.next_in = inBytes;
            zStream.next_in_index = 0;
            zStream.avail_in = inBytes.Length;
            zStream.next_out = outBytes;
            zStream.next_out_index = 0;
            zStream.avail_out = outBytes.Length;
            int retval = 0;

            do {
                retval = zStream.inflate(zlibConst.Z_SYNC_FLUSH);
                switch (retval) {
                    case zlibConst.Z_OK:
                    // completed decompression, lets copy data and get out
                    case zlibConst.Z_BUF_ERROR:
                        // need more space for output. store current output and get more
                        outBuffer.Put(outBytes, 0, zStream.next_out_index);
                        zStream.next_out_index = 0;
                        zStream.avail_out = outBytes.Length;
                        break;
                    default:
                        // unknown error
                        outBuffer = null;
                        if (zStream.msg == null) {
                            throw new Exception("Unknown error. Error code : " + retval);
                        } else {
                            throw new Exception("Unknown error. Error code : " + retval + " and message : " + zStream.msg);
                        }
                }
            } while (zStream.avail_in > 0);


            outBuffer.Flip();
            byte[] retBytes = new byte[outBuffer.Remaining];
            outBuffer.Get(retBytes);

            zStream.free();
            return retBytes;
        }

    }

}
