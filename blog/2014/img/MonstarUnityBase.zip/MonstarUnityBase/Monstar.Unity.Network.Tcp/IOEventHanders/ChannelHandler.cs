﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp.IOEventHanders {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-12-1
    //
    //======================================================================

    /// <summary>
    /// (消息)频道处理器
    /// </summary>
    public class ChannelHandler : IOEventHandler {

        public IOEventHandler PrevHander {
            get;
            set;
        }

        public IOEventHandler NextHander {
            get;
            set;
        }

        public void HandleIoWriteEvent(IRemoter remoter, IRequestWrapper data) {
            // 频道不可写，因此，只需简单传递写事件
            PrevHander.HandleIoWriteEvent(remoter, data);
        }

        public void HandleIoReadEvent(IRemoter remoter, IResponseWrapper data) {
            throw new NotImplementedException();
        }

        public void HandleIoIdleEvent(IRemoter remoter) {
            NextHander.HandleIoIdleEvent(remoter);
        }
    }
}
