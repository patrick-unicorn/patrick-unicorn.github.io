﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp {

    /* ======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :      

    //        created by unicorn(haiyin-ma) at  2014-11-25
    //
    //====================================================================== */

    public interface IEncrypter {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="inBytes"></param>
        /// <returns></returns>
        byte[] Encrypt(byte[] inBytes);
    }

    public interface IDecrypter {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="inBytes"></param>
        /// <returns></returns>
        byte[] Decrypt(byte[] inBytes);
    }

    public interface IEncryptionFactory {

        IEncrypter Encrypter { get; }

        IDecrypter Decrypter { get; }

    }

    public class NopEncrypter : IEncrypter {

        #region IEncrypter Members

        public byte[] Encrypt(byte[] inBytes) {
            return inBytes;
        }

        #endregion
    }

    public class NopDecrypter : IDecrypter {

        #region IDecrypter Members

        public byte[] Decrypt(byte[] inBytes) {
            return inBytes;
        }

        #endregion
    }

    public class NopEncryptionFactory : IEncryptionFactory {

        public IEncrypter Encrypter {
            get { return new NopEncrypter(); }
        }

        public IDecrypter Decrypter {
            get { return new NopDecrypter(); }
        }
    }
}
