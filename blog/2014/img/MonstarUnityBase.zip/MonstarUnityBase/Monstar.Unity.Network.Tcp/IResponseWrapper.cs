﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-11-23
    //
    //======================================================================

    /// <summary>
    /// 接收数据对象包装接口
    /// </summary>
    public interface IResponseWrapper {

        /// <summary>
        /// 是否单向消息
        /// </summary>
        bool? IsMessage { get; }

        /// <summary>
        /// 原始接收数据对象
        /// </summary>
        object Data { get; }

        /// <summary>
        /// 替换<code>Data</code>并返回新实例
        /// </summary>
        /// <param name="newData"></param>
        /// <returns></returns>
        IResponseWrapper New(object newData);

    }

    public class DefaultResponse : IResponseWrapper {

        private object data;

        private bool? isMessage;

        public object Data {
            get { return data; }
        }

        public bool? IsMessage {
            get { return isMessage; }
        }

        public DefaultResponse(object data) : this(data, null) {

        }

        public DefaultResponse(object data, bool? isMessage) {
            if (data is IRequestWrapper) {
                throw new ArgumentException("Data");
            }
            this.data = data;
            this.isMessage = isMessage;
        }

        public IResponseWrapper New(object newData) {
            if (newData is IResponseWrapper) {
                return (IResponseWrapper) newData;
            }
            return new DefaultResponse(newData, isMessage);
        }

    }
}
