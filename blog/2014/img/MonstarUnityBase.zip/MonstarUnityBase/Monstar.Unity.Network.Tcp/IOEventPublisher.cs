﻿using Monstar.Unity.Utility;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp {

    /* ======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :      

    //        created by unicorn(haiyin-ma) at  2014-11-25
    //
    //====================================================================== */

    /// <summary>
    /// 写事件委托
    /// </summary>
    /// <param name="remoter"></param>
    /// <param name="packet"></param>
    /// <returns>true - 继续执行委托链; false - 中断执行委托链</returns>
    public delegate void IoWriteHandler(IRemoter remoter, IRequestWrapper data);

    /// <summary>
    /// 读事件委托
    /// </summary>
    /// <param name="remoter"></param>
    /// <param name="packet"></param>
    /// <returns>true - 继续执行委托链; false - 中断执行委托链</returns>
    public delegate void IoReadHandler(IRemoter remoter, IResponseWrapper data);

    /// <summary>
    /// 空闲事件委托
    /// </summary>
    /// <param name="remoter"></param>
    /// <returns>true - 继续执行委托链; false - 中断执行委托链</returns>
    public delegate void IoIdleHandler(IRemoter remoter);

    /// <summary>
    /// Io事件发布接口
    /// </summary>
    public interface IOEventPublisher {

        /// <summary>
        /// 实际IO写入事件
        /// </summary>
        event IoWriteHandler IoWriteEvent;

        /// <summary>
        /// 实际IO读取事件
        /// </summary>
        event IoReadHandler IoReadEvent;

        /// <summary>
        /// IO空闲事件
        /// </summary>
        event IoIdleHandler IoIdleEvent;

        /// <summary>
        /// 触发IO写入事件
        /// </summary>
        /// <param name="remoter"></param>
        /// <param name="packet"></param>
        void FireIoWriteEvent(IRemoter remoter, IRequestWrapper packet);

        /// <summary>
        /// 触发IO读取事件
        /// </summary>
        /// <param name="remoter"></param>
        /// <param name="packet"></param>
        void FireIoReadEvent(IRemoter remoter, IResponseWrapper packet);

        /// <summary>
        /// 触发IO空闲事件
        /// </summary>
        /// <param name="remoter"></param>
        void FireIoIdleEvent(IRemoter remoter);

    }
}
