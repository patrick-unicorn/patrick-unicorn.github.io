﻿using log4net;
using Monstar.U3D.Utility;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

/* ======================================================================
//
//        Copyright(c)  http://www.monstar-lab.com/
//        All rights reserved

//        CLR:               .NET Framework 2.0           
//        description :      

//        created by unicorn(haiyin-ma) at  2014-11-25
//
//====================================================================== */

namespace Monstar.Unity.Network.Tcp {

    /// <summary>
    /// 异常处理句柄
    /// </summary>
    /// <param name="cause"></param>
    /// <param name="state"></param>
    public delegate void ExceptionCaught(Exception cause, object state);

    public interface IRemoter {

        /// <summary>
        /// Ping值
        /// </summary>
        long Ping { get; set; }

        /// <summary>
        /// 是否停止
        /// </summary>
        bool IsStoped { get; }

        /// <summary>
        /// 启动时间
        /// </summary>
        long StartTime { get; }

        /// <summary>
        /// Io连接对象
        /// </summary>
        IConnector Connector { get; }

        /// <summary>
        /// Io事件处理器
        /// </summary>
        IOProcessor Processor { get; }

        /// <summary>
        /// 配置对象
        /// </summary>
        RemoterConfig Configure { get; set; }

        /// <summary>
        /// 日志对象
        /// </summary>
        ILog L { get; set; }

        /// <summary>
        /// 全局异常处理句柄
        /// </summary>
        ExceptionCaught ExceptionHandler { set; }

        /// <summary>
        /// (接收)数据处理器
        /// </summary>
        IDataHandler DataHandler { get; set; }

        /// <summary>
        /// IO事件处理链构造器
        /// </summary>
        IOEventHandlerChainBuilder IOEventHandlerChainBuilder { get; }

        /// <summary>
        /// 启动
        /// </summary>
        /// <param name="state"></param>
        void Start(object state);

        /// <summary>
        /// 停止
        /// </summary>
        /// <param name="state"></param>
        void Stop(object state);

        /// <summary>
        /// 同步发送请求
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        object Request(object request);

        /// <summary>
        /// 同步发送请求
        /// </summary>
        /// <param name="request"></param>
        /// <param name="timeout">最大阻塞时间(毫秒)</param>
        /// <returns></returns>
        object Request(object request, int timeout);

        /// <summary>
        /// 同步发送请求
        /// </summary>
        /// <param name="request"></param>
        /// <param name="callback">同步回调函数</param>
        /// <param name="timeout"></param>
        /// <returns></returns>
        object Request(object request, MSyncCallback callback, int timeout);

        /// <summary>
        /// 异步发送请求
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="request"></param>
        /// <param name="asyncCallback">
        /// 消息响应收到后执行的异步操作。需要特别注意的一点是，该异步操作中不应包含如下类型操作：
        ///     1. 必须在UI线程中完成的操作。
        ///     2. 任何耗时的操作。
        /// </param>
        /// <returns>同步句柄</returns>
        ManualResetEvent AsyncRequest(object request, MAsyncCallback callback);

        /// <summary>
        /// 发送(无响应）消息
        /// </summary>
        /// <param name="request"></param>
        void PushOutMessage(object message);

        /// <summary>
        /// 订阅(服务端)消息频道
        /// </summary>
        /// <typeparam name="M">消息对象类型</typeparam>
        /// <param name="channel">消息频道ID</param>
        /// <param name="handler">消息处理器</param>
        /// <remarks>
        /// 使用者需要确保提供的消息判别器<param name="channel"></param>的唯一可判定性，即
        /// 不能对同一个消息出现两个判定器均成功的情况。
        /// </remarks>
        void Subscribe(IChannel channel);

        /// <summary>
        /// 移除属性
        /// </summary>
        bool RemoveAttribute(object key);

        /// <summary>
        /// 获取属性对象
        /// </summary>
        /// <param name="key"></param>
        /// <returns>如果key不存在返回null</returns>
        object GetAttribute(object key);

        /// <summary>
        /// 添加属性
        /// </summary>
        void AddAttribute(object key, object attr);

        /// <summary>
        /// 如果缺失则添加属性
        /// </summary>
        bool AddAttributeIfAbsent(object key, object attr);

        /// <summary>
        /// 异常处理函数
        /// 
        /// 内部调用<code>IRemoter.ExceptionHandler</code>
        /// </summary>
        /// <param name="handler"></param>
        void HandleException(Exception e, object state);
    }
}
