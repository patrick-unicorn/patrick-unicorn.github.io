﻿using Monstar.Unity.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp {

    /* ======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :      

    //        created by unicorn(haiyin-ma) at  2014-11-25
    //
    //====================================================================== */

    /// <summary>
    /// IO事件订阅者
    /// 
    /// 与IO事件发布者<see cref="IOEventPublisher"/>共同构建事件-订阅模式。在每个实现中，
    /// 通过调用<code>PrevHander</code>和<code>NextHander</code>传递执行链。具体的调用情形如下：
    /// 
    /// 1. HandleIoWriteEvent   与<code>IOEventHandlerChain#Append</code>构造顺序<em>相反</em>
    /// 2. HandleIoReadEvent    与<code>IOEventHandlerChain#Append</code>构造顺序<em>一致</em>
    /// 3. HandleIoIdleEvent    与<code>IOEventHandlerChain#Append</code>构造顺序<em>一致</em>
    /// </summary>
    public interface IOEventHandler {

        IOEventHandler PrevHander { get; set; }

        IOEventHandler NextHander { get; set; }

        void HandleIoWriteEvent(IRemoter remoter, IRequestWrapper data);

        void HandleIoReadEvent(IRemoter remoter, IResponseWrapper data);

        void HandleIoIdleEvent(IRemoter remoter);

    }

    public interface IOEventHandlerChain {

        IOEventHandler Head { get; }

        IOEventHandler Tail { get; }

    }

    /// <summary>
    /// <see cref="IOEventHandler"/>处理链构造器接口
    /// </summary>
    public interface IOEventHandlerChainBuilder {

        IOEventPublisher EventPublisher { get; }

        IOEventHandlerChain HandlerChain { get; }

        IOEventHandlerChainBuilder Append(IOEventHandler ioHander);

    }

    class HeadIOHandler : IOEventHandler {

        private IOEventHandler prevHander;

        public IOEventHandler PrevHander {
            get {
                return null;
            }
            set {
                prevHander = value;
            }
        }

        public IOEventHandler NextHander {
            get;
            set;
        }

        public void HandleIoWriteEvent(IRemoter remoter, IRequestWrapper data) {
            IoBuffer packet = data.Data as IoBuffer;
            if (packet == null) {
                throw new ArgumentException("The Write Packet Object Must Be [IoBuffer]");
            }
            remoter.Processor.WritePacket(packet);
        }

        public void HandleIoReadEvent(IRemoter remoter, IResponseWrapper data) {
            NextHander.HandleIoReadEvent(remoter, data);
        }

        public void HandleIoIdleEvent(IRemoter remoter) {
            NextHander.HandleIoIdleEvent(remoter);
        }
    }

    class TailIOHandler : IOEventHandler {

        public IOEventHandler PrevHander {
            get;
            set;
        }

        private IOEventHandler nextHander;

        public IOEventHandler NextHander {
            get {
                return null;
            }
            set {
                nextHander = value;
            }
        }

        public void HandleIoWriteEvent(IRemoter remoter, IRequestWrapper data) {
            PrevHander.HandleIoWriteEvent(remoter, data);
        }

        public void HandleIoReadEvent(IRemoter remoter, IResponseWrapper data) {
            remoter.DataHandler.DataRecieved(remoter, data);
        }

        public void HandleIoIdleEvent(IRemoter remoter) {
            // NOP.
        }
    }

    class DefaultIOEventHandlerChain : IOEventHandlerChain {

        public IOEventHandler Head { get; private set; }

        public IOEventHandler Tail { get; private set; }

        public DefaultIOEventHandlerChain(IOEventHandler head, IOEventHandler tail) {
            this.Head = head;
            this.Tail = tail;
            this.Head.NextHander = this.Tail;
            this.Tail.PrevHander = this.Head;
        }

        public override string ToString() {
            StringBuilder sBuilder = new StringBuilder();
            IOEventHandler point = Head;
            while (point != null) {
                sBuilder.Append(point.GetType().Name)
                        .Append(";");
                point = point.NextHander;
            }
            return sBuilder.ToString();
        }
    }

    /// <summary>
    /// 默认<see cref="IOEventHandler"/>处理链构造器
    /// </summary>
    public class DefaultIOEventHandlerChainBuilder : IOEventHandlerChainBuilder {

        private IOEventHandlerChain handlerChain;

        private IOEventPublisher eventPublisher;

        private List<Type> handlerTypeList;

        public IOEventHandlerChain HandlerChain {
            get { return handlerChain; }
        }

        public IOEventPublisher EventPublisher {
            get { return eventPublisher; }
        }

        public DefaultIOEventHandlerChainBuilder(IOEventPublisher eventPublisher) {
            this.eventPublisher = eventPublisher;
            this.handlerTypeList = new List<Type>();
            this.handlerChain = new DefaultIOEventHandlerChain(new HeadIOHandler(), new TailIOHandler());
            eventPublisher.IoWriteEvent += this.handlerChain.Tail.HandleIoWriteEvent;
            eventPublisher.IoReadEvent  += this.handlerChain.Head.HandleIoReadEvent;
            eventPublisher.IoIdleEvent  += this.handlerChain.Head.HandleIoIdleEvent;
        }

        public IOEventHandlerChainBuilder Append(IOEventHandler ioHander) {
            if (handlerTypeList.Contains(ioHander.GetType())) {
                throw new ArgumentException(
                    string.Format("Duplicate type:{0}", ioHander.GetType()));
            }
            IOEventHandler secondTailHandler = handlerChain.Tail.PrevHander;
            IOEventHandler tailHandler = handlerChain.Tail;

            secondTailHandler.NextHander = ioHander;
            ioHander.PrevHander = secondTailHandler;

            tailHandler.PrevHander = ioHander;
            ioHander.NextHander = tailHandler;
            return this;
        }

    }

}
