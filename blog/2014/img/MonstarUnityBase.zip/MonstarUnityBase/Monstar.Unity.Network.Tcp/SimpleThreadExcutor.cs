﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Threading;

namespace Monstar.Unity.Network.Tcp {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-11-23
    //
    //======================================================================

    /// <summary>
    /// 简单线程池包装类
    /// </summary>
    class SimpleThreadExcutor : IExcutor {
        
        private const int DEFAULT_WORKER_THREADS = 1;

        private const int DEFAULT_COMPLETION_THREADS = 1;

        private int workerThreads;

        private int completionThreads;

        public SimpleThreadExcutor()
            : this(DEFAULT_WORKER_THREADS, DEFAULT_COMPLETION_THREADS) {

        }

        public SimpleThreadExcutor(int workerThreads, int completionThreads) {
            this.workerThreads = workerThreads;
            this.completionThreads = completionThreads;

            ThreadPool.SetMaxThreads(workerThreads, completionThreads);
            ThreadPool.SetMinThreads(workerThreads, completionThreads);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="task"></param>
        public void Excute(WaitCallback task) {
            Excute(task, null);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="task"></param>
        public void Excute(WaitCallback task, object state) {
            ThreadPool.QueueUserWorkItem(task, state);
        }

    }
}
