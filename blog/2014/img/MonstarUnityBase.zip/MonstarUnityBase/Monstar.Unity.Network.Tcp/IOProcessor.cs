﻿using Monstar.Unity.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp {

    /// <summary>
    /// IO时间处理器接口
    /// </summary>
    public interface IOProcessor {

        IRemoter Remoter { get; set; }

        IExcutor Excutor { get; }

        IOEventPublisher IOEventPublisher { get; }

        /// <summary>
        /// 是否可读
        /// </summary>
        bool CanRead { get; }

        /// <summary>
        /// 是否可写
        /// </summary>
        bool CanWrite { get; }

        /// <summary>
        /// 运行
        /// </summary>
        void Run();

        /// <summary>
        /// 数据对象写入队列
        /// </summary>
        /// <param name="request"></param>
        void WriteRequest(IRequestWrapper request);

        /// <summary>
        /// 写出数据包
        /// </summary>
        /// <param name="remoter"></param>
        /// <param name="packet"></param>
        void WritePacket(IoBuffer packet);

        /// <summary>
        /// 读取等待响应请求队列
        /// </summary>
        IRequestWrapper ReadRequest();

        /// <summary>
        /// 停止并释放资源
        /// </summary>
        void Dispose();

        /// <summary>
        /// 是否空闲
        /// </summary>
        bool IsIdle { get; }

        /// <summary>
        /// IO最近读取时间
        /// </summary>
        long LastIoReadTime { get; set; }

        /// <summary>
        /// IO最近写入时间
        /// </summary>
        long LastIoWriteTime { get; set; }
    }
}
