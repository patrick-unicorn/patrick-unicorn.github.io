﻿using Monstar.U3D.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp {

    /* ======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :      

    //        created by unicorn(haiyin-ma) at  2014-11-25
    //
    //====================================================================== */

    /// <summary>
    /// 接收端数据对象处理器接口
    /// </summary>
    public interface IDataHandler {

        /// <summary>
        /// 获取频道列表
        /// 
        /// <remarks>
        /// 外部应用需要循环检测频道是否有消息，并及时调用<code>IChannel#ProcessMessage</code>处理频道消息。
        /// </remarks>
        /// </summary>
        ICollection<IChannel> ChannelList { get; }

        /// <summary>
        /// 注册频道
        /// </summary>
        /// <param name="channel"></param>
        void RegisterChannel(IChannel channel);

        /// <summary>
        /// 获取最新响应回调对象
        /// </summary>
        IAsyncCallbackTask LatestCallBackTask { get; }

        /// <summary>
        /// (接收)数据处理
        /// </summary>
        /// <param name="data"></param>
        void DataRecieved(IRemoter remoter, IResponseWrapper data);

    }

    /// <summary>
    /// 接收端数据对象处理器抽象基类
    /// </summary>
    public abstract class AbstractDataHandler : IDataHandler {

        private ConcurrencyQueue<IAsyncCallbackTask> responseTaskQueue;

        private IDictionary<Type, IChannel> channels;

        public IAsyncCallbackTask LatestCallBackTask {
            get { return responseTaskQueue.Dequeue(); }
        }

        public ICollection<IChannel> ChannelList {
            get { return channels.Values; }
        }

        public void RegisterChannel(IChannel channel) {
            if (channels.ContainsKey(channel.GetType())) {
                throw new ArgumentException(
                    string.Format("Duplicate Channel:{0}", channel.GetType()));
            }
            channels.Add(channel.GetType(), channel);
        }

        public AbstractDataHandler() {
            channels = new Dictionary<Type, IChannel>();
            responseTaskQueue = new ConcurrencyQueue<IAsyncCallbackTask>();
        }

        public void DataRecieved(IRemoter remoter, IResponseWrapper data) {
            if (!data.IsMessage.Value) {
                IRequestWrapper requst = remoter.Processor.ReadRequest();
                requst.ResponseTask.AsyncResult = data;
                responseTaskQueue.Enqueue(requst.ResponseTask);
                if (requst.ResponseTask.WaitHandle != null) {
                    requst.ResponseTask.WaitHandle.Set();
                }
            } else {
                throw new NotSupportedException("Received Data(Type)");
                // TODO: 处理Channel消息
            }
        }

    }
}
