﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;

namespace Monstar.Unity.Network.Tcp {

    /* ======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :      

    //        created by unicorn(haiyin-ma) at  2014-11-25
    //
    //====================================================================== */

    public interface IConnector {

        /// <summary>
        /// Socket对象
        /// </summary>
        Socket UnderlyingSocket { get; }

        /// <summary>
        /// Remoter对象
        /// </summary>
        IRemoter Remoter { get; set; }

        /// <summary>
        /// 是否连接
        /// </summary>
        bool Connected { get; }

        /// <summary>
        /// 建立网络Socket连接
        /// </summary>
        bool Connect();

    }
}
