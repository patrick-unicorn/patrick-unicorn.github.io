﻿using Monstar.Unity.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-11-23
    //
    //======================================================================

    public class TcpConnector : IConnector {

        private IRemoter remoter;

        private Socket socket;

        private ManualResetEvent waitHandle;

        private string host;

        private int port;

        public long LastIoReadTime {
            get;
            set;
        }

        public long LastIoWriteTime {
            get;
            set;
        }

        public Socket UnderlyingSocket {
            get { return socket; }
        }

        public bool Connected {
            get { return socket.Connected; }
        }

        public IRemoter Remoter {
            get { return remoter; }
            set {
                remoter = value;
            }
        }

        public TcpConnector() {
            this.waitHandle = new ManualResetEvent(false);
        }

        public bool Connect() {
            try {
                host = Remoter.Configure.Host;
                port = Remoter.Configure.Port;

                socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                socket.ReceiveBufferSize = remoter.Configure.RecieveBufferSize;
                socket.SendBufferSize = remoter.Configure.SendBufferSize;

                SocketAsyncEventArgs socketEventArg = new SocketAsyncEventArgs();
                socketEventArg.Completed += new EventHandler<SocketAsyncEventArgs>(ConnectCompleted);
                socketEventArg.RemoteEndPoint = new IPEndPoint(IPAddress.Parse(host), port);
                socketEventArg.UserToken = socket;
                socket.ConnectAsync(socketEventArg);

                waitHandle.WaitOne(remoter.Configure.ConnectTimeout);
                if (!socket.Connected) {
                    throw new TimeoutException(string.Format("Connect the server[{0}:{1}] failed!", host, port));
                }
            } catch (Exception e) {
                remoter.HandleException(e, "Connection");
            } finally {
                waitHandle.Set();
            }
            return socket.Connected;
        }

        private void ConnectCompleted(object sender, SocketAsyncEventArgs e) {
            if (e.LastOperation == SocketAsyncOperation.Connect) {
                if (e.SocketError == SocketError.Success) {
                    remoter.L.Info(string.Format("Connect the server[{0}:{1}] successfully", host, port));
                    waitHandle.Set();
                } else {
                    throw new SocketException((int) e.SocketError);
                }
            }
        }

    }
}
