﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Monstar.Unity.Network.Tcp {

    //======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :          

    //        created by unicorn(haiyin-ma) at  2013-11-23
    //
    //======================================================================

    /// <summary>
    /// 发送数据对象包装接口
    /// </summary>
    public interface IRequestWrapper {

        /// <summary>
        /// 是否单向消息
        /// </summary>
        bool? IsMessage { get; }

        /// <summary>
        /// 请求数据对象
        /// </summary>
        object Data { get; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="newData"></param>
        /// <returns></returns>
        IRequestWrapper New(object newData);

        /// <summary>
        /// 响应结果Task包装
        /// </summary>
        IAsyncCallbackTask ResponseTask {
            get;
            set;
        }

    }

    /// <summary>
    /// 默认实现
    /// </summary>
    public class DefaultRequest : IRequestWrapper {

        private object data;

        private bool? isMessage;

        public object Data {
            get { return data; }
        }

        public bool? IsMessage {
            get { return isMessage; }
        }

        public ManualResetEvent WaitHandle {
            get;
            set;
        }

        public IAsyncCallbackTask ResponseTask {
            get;
            set;
        }

        public DefaultRequest(object data) : this(data, null) {

        }

        public DefaultRequest(object data, bool? isMessage) {
            if (data is IRequestWrapper) {
                throw new ArgumentException("Data");
            }
            this.data = data;
            this.isMessage = isMessage;
            this.ResponseTask = new AsyncCallbackTask();
        }

        public IRequestWrapper New(object newData) {
            if (newData is IRequestWrapper) {
                return (IRequestWrapper) newData;
            }
            return new DefaultRequest(newData, isMessage);
        }
    }
}
