﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Threading;

namespace Monstar.Unity.Network.Tcp {

    /* ======================================================================
    //
    //        Copyright(c)  http://www.monstar-lab.com/
    //        All rights reserved

    //        CLR:               .NET Framework 2.0           
    //        description :      

    //        created by unicorn(haiyin-ma) at  2014-11-25
    //
    //====================================================================== */

    /// <summary>
    /// 同步完成操作
    /// </summary>
    /// <param name="syncResult"></param>
    /// <param name="state"></param>
    public delegate void MSyncCallback(object syncResult, object state);

    /// <summary>
    /// 异步完成操作
    /// </summary>
    /// <param name="asyncResult"></param>
    /// <param name="state"></param>
    public delegate void MAsyncCallback(object asyncResult, object state);

    public interface IAsyncCallbackTask {

        /// <summary>
        /// 同步对象
        /// </summary>
        ManualResetEvent WaitHandle { get; set; }

        /// <summary>
        /// 回调执行方法
        /// </summary>
        MAsyncCallback MethodHandle { get; set; }
        
        /// <summary>
        /// 标识回调是否执行
        /// </summary>
        bool Activated { get; set; }

        /// <summary>
        /// 运行时传入的用户自定义对象。通常有<code>run（object state）</code>方法传入。
        /// </summary>
        object State { get; }

        /// <summary>
        /// 异步结果对象。比如：一个异步的Socket消息对象。
        /// </summary>
        object AsyncResult { get; set; }

        /// <summary>
        /// 执行异步完成操作。
        /// </summary>
        void Run();

        /// <summary>
        /// 执行异步完成操作，并传入运行时自定义用户对象。
        /// </summary>
        /// <param name="state"></param>
        void Run(object state);

    }

    public class AsyncCallbackTask : IAsyncCallbackTask {

        public bool Activated {
            get;
            set;
        }

        public object State {
            get;
            private set;
        }

        public object AsyncResult {
            get;
            set;
        }

        public ManualResetEvent WaitHandle {
            get;
            set;
        }

        public MAsyncCallback MethodHandle {
            get;
            set;
        }

        public void Run() {
            Run(null);
        }

        public void Run(object state) {
            if (MethodHandle != null) {
                this.State = state;
                MethodHandle(AsyncResult, state);
            }
        }

    }

}
